using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace SolidDNA
{
    /// <summary>
    /// Read-only configuration comparison surface. It uses SOLIDWORKS' own
    /// configuration activation and graphics view; it does not edit models.
    /// </summary>
    internal sealed class AssemblyConfigurationMatrixForm : Form
    {
        private readonly ISldWorks swApp;
        private readonly IModelDoc2 model;
        private readonly IAssemblyDoc assembly;
        private readonly string documentPath;
        private readonly string documentTitle;
        private readonly DataGridView matrix = new DataGridView();
        private readonly ComboBox configurationPicker = new ComboBox();
        private readonly Label documentLabel = new Label();
        private readonly Label sourceLabel = new Label();
        private readonly Label statusLabel = new Label();
        private readonly Button showButton = new Button();
        private readonly Button refreshButton = new Button();
        private bool loading;

        private sealed class ComponentInfo
        {
            public string Key;
            public string Instance;
            public string Description;
            public Dictionary<string, string> States = new Dictionary<string, string>(StringComparer.Ordinal);
        }

        public AssemblyConfigurationMatrixForm(ISldWorks application, IModelDoc2 assemblyModel)
        {
            swApp = application;
            model = assemblyModel;
            assembly = assemblyModel as IAssemblyDoc;
            documentPath = SafePath(assemblyModel);
            documentTitle = SafeTitle(assemblyModel);

            Text = "Cabin Tools - Assembly Configuration Matrix";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(820, 430);
            Size = new Size(1120, 690);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            BackColor = Color.FromArgb(244, 246, 248);
            BuildLayout();
            LoadMatrix();
        }

        public bool BelongsTo(IModelDoc2 candidate)
        {
            if (candidate == null)
                return false;
            string candidatePath = SafePath(candidate);
            return !string.IsNullOrWhiteSpace(documentPath)
                ? string.Equals(documentPath, candidatePath, StringComparison.OrdinalIgnoreCase)
                : string.IsNullOrWhiteSpace(candidatePath) && string.Equals(documentTitle, SafeTitle(candidate), StringComparison.OrdinalIgnoreCase);
        }

        private void BuildLayout()
        {
            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(12),
                ColumnCount = 1,
                RowCount = 4,
                BackColor = BackColor
            };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            TableLayoutPanel heading = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 1,
                Padding = new Padding(10),
                Margin = new Padding(0, 0, 0, 8),
                BackColor = Color.White,
                CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
            };
            documentLabel.AutoSize = true;
            documentLabel.Font = new Font(Font, FontStyle.Bold);
            sourceLabel.AutoSize = true;
            sourceLabel.ForeColor = Color.FromArgb(75, 85, 95);
            heading.Controls.Add(documentLabel, 0, 0);
            heading.Controls.Add(sourceLabel, 0, 1);
            root.Controls.Add(heading, 0, 0);

            FlowLayoutPanel actions = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                WrapContents = true,
                Margin = new Padding(0, 0, 0, 8)
            };
            actions.Controls.Add(new Label { Text = "View configuration", AutoSize = true, Margin = new Padding(0, 8, 6, 0) });
            configurationPicker.DropDownStyle = ComboBoxStyle.DropDownList;
            configurationPicker.Width = 220;
            actions.Controls.Add(configurationPicker);
            showButton.Text = "Show";
            showButton.AutoSize = true;
            showButton.Click += ShowButton_Click;
            StyleButton(showButton, true);
            actions.Controls.Add(showButton);
            refreshButton.Text = "Refresh";
            refreshButton.AutoSize = true;
            refreshButton.Click += delegate { LoadMatrix(); };
            StyleButton(refreshButton, false);
            actions.Controls.Add(refreshButton);
            root.Controls.Add(actions, 0, 1);

            matrix.Dock = DockStyle.Fill;
            matrix.ReadOnly = true;
            matrix.AllowUserToAddRows = false;
            matrix.AllowUserToDeleteRows = false;
            matrix.AllowUserToResizeRows = false;
            matrix.MultiSelect = false;
            matrix.SelectionMode = DataGridViewSelectionMode.CellSelect;
            matrix.RowHeadersVisible = false;
            matrix.BackgroundColor = Color.White;
            matrix.BorderStyle = BorderStyle.FixedSingle;
            matrix.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            matrix.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(232, 237, 242);
            matrix.EnableHeadersVisualStyles = false;
            matrix.DefaultCellStyle.SelectionBackColor = Color.FromArgb(217, 234, 249);
            matrix.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 40, 50);
            matrix.RowTemplate.Height = 27;
            root.Controls.Add(matrix, 0, 2);

            statusLabel.AutoSize = true;
            statusLabel.BorderStyle = BorderStyle.FixedSingle;
            statusLabel.BackColor = Color.White;
            statusLabel.Padding = new Padding(8, 6, 8, 6);
            statusLabel.Margin = new Padding(0, 8, 0, 0);
            root.Controls.Add(statusLabel, 0, 3);

            Controls.Add(root);
        }

        private static void StyleButton(Button button, bool primary)
        {
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = primary ? 0 : 1;
            button.FlatAppearance.BorderColor = Color.FromArgb(190, 198, 206);
            button.Padding = new Padding(9, 3, 9, 3);
            if (primary)
            {
                button.BackColor = Color.FromArgb(0, 103, 184);
                button.ForeColor = Color.White;
            }
            else
            {
                button.BackColor = Color.White;
                button.ForeColor = Color.FromArgb(35, 45, 55);
            }
        }

        private void LoadMatrix()
        {
            if (loading || IsDisposed)
                return;

            loading = true;
            Cursor priorCursor = Cursor;
            string originalConfiguration = null;
            Cursor = Cursors.WaitCursor;
            try
            {
                ValidatePinnedDocument();
                string activeName = ActiveConfigurationName();
                originalConfiguration = activeName;
                if (string.IsNullOrWhiteSpace(activeName))
                    throw new InvalidOperationException("SOLIDWORKS did not report an active assembly configuration. No scan was started.");
                List<string> configurations = ReadConfigurationNames(model);
                if (configurations.Count == 0)
                    throw new InvalidOperationException("No assembly configurations were found.");

                documentLabel.Text = SafeTitle(model) + "  ·  Viewed: " + Display(activeName);
                sourceLabel.Text = ReadDesignTableStatus(model);
                configurationPicker.BeginUpdate();
                try
                {
                    configurationPicker.Items.Clear();
                    foreach (string name in configurations)
                        configurationPicker.Items.Add(name);
                    configurationPicker.SelectedItem = configurations.Contains(activeName) ? activeName : configurations[0];
                }
                finally { configurationPicker.EndUpdate(); }

                Dictionary<string, ComponentInfo> inventory = new Dictionary<string, ComponentInfo>(StringComparer.OrdinalIgnoreCase);
                List<string> scanErrors = new List<string>();
                foreach (string configuration in configurations)
                {
                    if (!Activate(configuration))
                    {
                        scanErrors.Add(configuration + ": could not activate");
                        continue;
                    }

                    foreach (IComponent2 component in ReadTopLevelComponents())
                    {
                        string instance = SafeComponentName(component);
                        if (string.IsNullOrWhiteSpace(instance))
                            continue;
                        string path = SafeComponentPath(component);
                        string key = instance + "|" + path;
                        ComponentInfo info;
                        if (!inventory.TryGetValue(key, out info))
                        {
                            info = new ComponentInfo
                            {
                                Key = key,
                                Instance = instance,
                                Description = Path.GetFileNameWithoutExtension(path)
                            };
                            inventory.Add(key, info);
                        }

                        int suppression = SafeSuppression(component);
                        string state = suppression < 0
                            ? "Unknown"
                            : suppression == (int)swComponentSuppressionState_e.swComponentSuppressed
                                ? "Suppressed"
                                : "Present";
                        string referenced = SafeReferencedConfiguration(component);
                        info.States[configuration] = state != "Present"
                            ? state
                            : state + (string.IsNullOrWhiteSpace(referenced) ? string.Empty : " · " + referenced);
                    }
                }

                if (!string.IsNullOrWhiteSpace(activeName) && !Activate(activeName))
                    throw new InvalidOperationException("The original configuration could not be restored after scanning.");
                originalConfiguration = null;

                BuildGrid(configurations, inventory);
                documentLabel.Text = SafeTitle(model) + "  ·  Viewed: " + Display(ActiveConfigurationName());
                statusLabel.ForeColor = scanErrors.Count == 0 ? Color.FromArgb(35, 45, 55) : Color.DarkRed;
                statusLabel.Text = scanErrors.Count == 0
                    ? inventory.Count + " component instance(s) across " + configurations.Count + " configuration(s). Read-only view; Apply is not enabled yet."
                    : "Inventory is incomplete: " + string.Join("; ", scanErrors.ToArray());
            }
            catch (Exception ex)
            {
                statusLabel.ForeColor = Color.DarkRed;
                statusLabel.Text = ex.Message;
            }
            finally
            {
                if (!string.IsNullOrWhiteSpace(originalConfiguration) &&
                    !string.Equals(ActiveConfigurationName(), originalConfiguration, StringComparison.Ordinal))
                {
                    if (!Activate(originalConfiguration))
                    {
                        statusLabel.ForeColor = Color.DarkRed;
                        statusLabel.Text = "Refresh ended before the original configuration could be restored. Please verify the active configuration.";
                    }
                }
                Cursor = priorCursor;
                loading = false;
            }
        }

        private void BuildGrid(List<string> configurations, Dictionary<string, ComponentInfo> inventory)
        {
            matrix.SuspendLayout();
            try
            {
                matrix.Columns.Clear();
                matrix.Rows.Clear();
                DataGridViewTextBoxColumn componentColumn = new DataGridViewTextBoxColumn
                {
                    HeaderText = "Component instance",
                    Frozen = true,
                    ReadOnly = true,
                    MinimumWidth = 230,
                    Width = 280,
                    SortMode = DataGridViewColumnSortMode.NotSortable
                };
                matrix.Columns.Add(componentColumn);
                foreach (string configuration in configurations)
                {
                    matrix.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        HeaderText = configuration,
                        MinimumWidth = 125,
                        Width = 150,
                        SortMode = DataGridViewColumnSortMode.NotSortable
                    });
                }

                List<ComponentInfo> ordered = new List<ComponentInfo>(inventory.Values);
                ordered.Sort(delegate(ComponentInfo a, ComponentInfo b)
                {
                    return string.Compare(a.Instance, b.Instance, StringComparison.OrdinalIgnoreCase);
                });
                foreach (ComponentInfo component in ordered)
                {
                    int row = matrix.Rows.Add();
                    matrix.Rows[row].Cells[0].Value = component.Description + "  [" + component.Instance + "]";
                    matrix.Rows[row].Cells[0].ToolTipText = component.Key;
                    for (int i = 0; i < configurations.Count; i++)
                    {
                        string state;
                        if (!component.States.TryGetValue(configurations[i], out state))
                            state = "Unknown";
                        matrix.Rows[row].Cells[i + 1].Value = state;
                        matrix.Rows[row].Cells[i + 1].ToolTipText = "Actual state read while this assembly configuration was active.";
                        matrix.Rows[row].Cells[i + 1].Style.ForeColor = state == "Unknown"
                            ? Color.FromArgb(125, 125, 125)
                            : state.StartsWith("Suppressed", StringComparison.Ordinal)
                                ? Color.FromArgb(130, 75, 75)
                                : Color.FromArgb(35, 85, 55);
                    }
                }
            }
            finally { matrix.ResumeLayout(); }
        }

        private IEnumerable<IComponent2> ReadTopLevelComponents()
        {
            object raw = null;
            try { raw = assembly.GetComponents(true); }
            catch { raw = null; }
            object[] values = raw as object[];
            if (values == null)
                yield break;
            foreach (object value in values)
            {
                IComponent2 component = value as IComponent2;
                if (component != null)
                    yield return component;
            }
        }

        private void ShowButton_Click(object sender, EventArgs e)
        {
            ShowSelectedConfiguration();
        }

        private void ShowSelectedConfiguration()
        {
            string name = configurationPicker.SelectedItem as string;
            if (string.IsNullOrWhiteSpace(name))
                return;
            try
            {
                ValidatePinnedDocument();
                if (!Activate(name))
                    throw new InvalidOperationException("SOLIDWORKS could not activate configuration '" + name + "'.");
                documentLabel.Text = SafeTitle(model) + "  ·  Viewed: " + name;
                statusLabel.ForeColor = Color.FromArgb(35, 45, 55);
                statusLabel.Text = "Showing '" + name + "' in the native SOLIDWORKS graphics area. No model data was changed.";
            }
            catch (Exception ex)
            {
                statusLabel.ForeColor = Color.DarkRed;
                statusLabel.Text = ex.Message;
            }
        }

        private bool Activate(string name)
        {
            try { return model.ShowConfiguration2(name); }
            catch { return false; }
        }

        private void ValidatePinnedDocument()
        {
            IModelDoc2 active = null;
            try { active = swApp.ActiveDoc as IModelDoc2; }
            catch { active = null; }
            if (model == null || assembly == null || active == null)
                throw new InvalidOperationException("The assembly this view belongs to is no longer active. Close and reopen the manager for the active assembly.");

            string activePath = SafePath(active);
            bool sameDocument = !string.IsNullOrWhiteSpace(documentPath)
                ? string.Equals(documentPath, activePath, StringComparison.OrdinalIgnoreCase)
                : string.IsNullOrWhiteSpace(activePath) && string.Equals(documentTitle, SafeTitle(active), StringComparison.OrdinalIgnoreCase);
            if (!sameDocument)
                throw new InvalidOperationException("The assembly this view belongs to is no longer active. Close and reopen the manager for the active assembly.");
        }

        private string ActiveConfigurationName()
        {
            try
            {
                ConfigurationManager manager = model.ConfigurationManager as ConfigurationManager;
                IConfiguration configuration = manager == null ? null : manager.ActiveConfiguration as IConfiguration;
                return configuration == null ? string.Empty : (configuration.Name ?? string.Empty);
            }
            catch { return string.Empty; }
        }

        private static List<string> ReadConfigurationNames(IModelDoc2 document)
        {
            List<string> names = new List<string>();
            object raw = null;
            try { raw = document.GetConfigurationNames(); }
            catch { raw = null; }
            Array values = raw as Array;
            if (values == null)
                return names;
            foreach (object value in values)
            {
                string name = Convert.ToString(value);
                if (!string.IsNullOrWhiteSpace(name) && !names.Contains(name))
                    names.Add(name);
            }
            return names;
        }

        private static string ReadDesignTableStatus(IModelDoc2 document)
        {
            try
            {
                IDesignTable table = document.GetDesignTable() as IDesignTable;
                if (table == null)
                    return "Source: no design table detected. Configuration edits are not enabled in this view.";
                string location = string.Empty;
                try { location = table.FileName ?? string.Empty; }
                catch { location = string.Empty; }
                bool linked = false;
                try { linked = table.LinkToFile; }
                catch { }
                return "Source: " + (linked ? "linked design table" : "embedded design table") +
                    (string.IsNullOrWhiteSpace(location) ? string.Empty : " · " + location) +
                    " · source-aware editing is not enabled in this build.";
            }
            catch
            {
                return "Source: design-table status could not be verified; view remains read-only.";
            }
        }

        private static int SafeSuppression(IComponent2 component)
        {
            try { return component.GetSuppression(); }
            catch { return -1; }
        }

        private static string SafeReferencedConfiguration(IComponent2 component)
        {
            try { return component.ReferencedConfiguration ?? string.Empty; }
            catch { return string.Empty; }
        }

        private static string SafeComponentName(IComponent2 component)
        {
            try { return component.Name2 ?? string.Empty; }
            catch { return string.Empty; }
        }

        private static string SafeComponentPath(IComponent2 component)
        {
            try { return component.GetPathName() ?? string.Empty; }
            catch { return string.Empty; }
        }

        private static string SafePath(IModelDoc2 document)
        {
            try { return document.GetPathName() ?? string.Empty; }
            catch { return string.Empty; }
        }

        private static string SafeTitle(IModelDoc2 document)
        {
            try { return document.GetTitle() ?? "Assembly"; }
            catch { return "Assembly"; }
        }

        private static string Display(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? "<unknown>" : value;
        }
    }
}

