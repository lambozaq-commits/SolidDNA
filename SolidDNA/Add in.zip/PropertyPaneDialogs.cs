using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace SolidDNA
{
    internal sealed class ConfigurationSelectionDialog : Form
    {
        private readonly CheckedListBox list = new CheckedListBox();
        public List<string> SelectedConfigurations { get; private set; }

        public ConfigurationSelectionDialog(IEnumerable<string> configurations, IEnumerable<string> selected)
        {
            Text = "Select configurations";
            StartPosition = FormStartPosition.CenterParent;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            Size = new Size(380, 430);
            PropertyPaneUi.Apply(this);

            HashSet<string> current = new HashSet<string>(selected ?? new string[0], StringComparer.OrdinalIgnoreCase);
            list.Dock = DockStyle.Fill;
            list.CheckOnClick = true;
            foreach (string name in configurations ?? new string[0])
                list.Items.Add(name, current.Contains(name));

            FlowLayoutPanel buttons = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 42,
                FlowDirection = FlowDirection.RightToLeft,
                Padding = new Padding(6)
            };
            Button ok = PropertyPaneUi.Button("OK", null, true);
            ok.DialogResult = DialogResult.OK;
            Button cancel = PropertyPaneUi.Button("Cancel", null, false);
            cancel.DialogResult = DialogResult.Cancel;
            buttons.Controls.Add(ok);
            buttons.Controls.Add(cancel);
            Controls.Add(list);
            Controls.Add(buttons);
            AcceptButton = ok;
            CancelButton = cancel;

            ok.Click += delegate
            {
                SelectedConfigurations = list.CheckedItems.Cast<object>().Select(Convert.ToString).ToList();
            };
        }
    }

    internal sealed class PropertyPaneSettingsForm : Form
    {
        private readonly PropertyPaneSettingsService service;
        private PropertyPaneProfile profile;
        private readonly ComboBox documentKind = new ComboBox();
        private readonly ListBox groups = new ListBox();
        private readonly DataGridView fields = Grid();
        private readonly ComboBox listName = new ComboBox();
        private readonly TextBox listValues = new TextBox();
        private readonly DataGridView mappings = Grid();
        private readonly DataGridView dimensions = Grid();
        private readonly TextBox catalogValues = new TextBox();
        private readonly CheckBox allowOverride = new CheckBox();
        private readonly CheckBox useSharedWorkbook = new CheckBox();
        private readonly TextBox workbookPath = new TextBox();
        private readonly Label workbookStatus = new Label();
        private readonly Button browseWorkbookButton = new Button();
        private readonly Button checkWorkbookButton = new Button();
        private FlowLayoutPanel listActions;

        public bool ProfileChanged { get; private set; }

        public PropertyPaneSettingsForm(PropertyPaneProfile current, PropertyPaneSettingsService settingsService)
        {
            service = settingsService;
            profile = service.Clone(current);
            Text = "Property pane settings";
            StartPosition = FormStartPosition.CenterParent;
            MinimumSize = new Size(820, 560);
            Size = new Size(980, 700);
            PropertyPaneUi.Apply(this);

            TabControl tabs = new TabControl { Dock = DockStyle.Fill };
            tabs.TabPages.Add(BuildLayoutTab());
            tabs.TabPages.Add(BuildSharedWorkbookTab());
            tabs.TabPages.Add(BuildListsTab());
            tabs.TabPages.Add(BuildMappingTab());
            tabs.TabPages.Add(BuildDimensionTab());
            tabs.TabPages.Add(BuildCatalogTab());

            FlowLayoutPanel footer = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 48,
                Padding = new Padding(8),
                FlowDirection = FlowDirection.RightToLeft
            };
            Button close = Button("Cancel", delegate { DialogResult = DialogResult.Cancel; Close(); });
            Button save = Button("Save", SaveAndClose);
            Button import = Button("Import", ImportProfile);
            Button export = Button("Export", ExportProfile);
            Button reset = Button("Reset", ResetProfile);
            footer.Controls.Add(close);
            footer.Controls.Add(save);
            footer.Controls.Add(export);
            footer.Controls.Add(import);
            footer.Controls.Add(reset);

            Controls.Add(tabs);
            Controls.Add(footer);
            LoadProfile();
        }

        private TabPage BuildLayoutTab()
        {
            TabPage page = new TabPage("Layout");
            SplitContainer split = new SplitContainer { Dock = DockStyle.Fill, SplitterDistance = 230 };

            documentKind.DropDownStyle = ComboBoxStyle.DropDownList;
            documentKind.Dock = DockStyle.Top;
            documentKind.DataSource = Enum.GetValues(typeof(PropertyPaneDocumentKind));
            documentKind.SelectedIndexChanged += delegate { BindGroups(); };

            groups.Dock = DockStyle.Fill;
            groups.DisplayMember = "Label";
            groups.SelectedIndexChanged += delegate { BindFields(); };
            FlowLayoutPanel groupButtons = Toolbar(
                Button("Add...", AddGroup), Button("Rename...", RenameGroup), Button("Remove", RemoveGroup),
                Button("Up", delegate { MoveGroup(-1); }), Button("Down", delegate { MoveGroup(1); }));
            split.Panel1.Controls.Add(groups);
            split.Panel1.Controls.Add(groupButtons);
            split.Panel1.Controls.Add(documentKind);

            fields.Dock = DockStyle.Fill;
            ConfigureFieldsGrid();
            FlowLayoutPanel fieldButtons = Toolbar(
                Button("Add...", AddField), Button("Edit...", EditField), Button("Remove", RemoveField),
                Button("Up", delegate { MoveField(-1); }), Button("Down", delegate { MoveField(1); }));
            split.Panel2.Controls.Add(fields);
            split.Panel2.Controls.Add(fieldButtons);
            page.Controls.Add(split);
            return page;
        }

        private TabPage BuildCatalogTab()
        {
            TabPage page = new TabPage("Property catalog");
            catalogValues.Dock = DockStyle.Fill;
            catalogValues.Multiline = true;
            catalogValues.ScrollBars = ScrollBars.Both;
            catalogValues.AcceptsReturn = true;
            page.Controls.Add(catalogValues);
            page.Controls.Add(new Label
            {
                Text = "One exact SOLIDWORKS property name per line.",
                Dock = DockStyle.Top,
                Height = 24
            });
            return page;
        }

        private TabPage BuildListsTab()
        {
            TabPage page = new TabPage("Lists");
            listName.Dock = DockStyle.Top;
            listName.DropDownStyle = ComboBoxStyle.DropDownList;
            listName.SelectedIndexChanged += delegate { BindListValues(); };
            listValues.Dock = DockStyle.Fill;
            listValues.Multiline = true;
            listValues.ScrollBars = ScrollBars.Both;
            listValues.AcceptsReturn = true;
            Label hint = new Label { Text = "One value per line. When shared Excel is enabled, edit the workbook through PDM.", Dock = DockStyle.Top, Height = 24 };
            listActions = Toolbar(Button("Update", UpdateList), Button("Add list", AddList), Button("Remove", RemoveList));
            page.Controls.Add(listValues);
            page.Controls.Add(listActions);
            page.Controls.Add(hint);
            page.Controls.Add(listName);
            return page;
        }

        private TabPage BuildSharedWorkbookTab()
        {
            TabPage page = new TabPage("Shared Excel");
            TableLayoutPanel layout = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 3,
                Padding = new Padding(16)
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

            useSharedWorkbook.Text = "Use shared Excel lists and drawing map";
            useSharedWorkbook.AutoSize = true;
            useSharedWorkbook.CheckedChanged += delegate { UpdateWorkbookMode(); };
            layout.Controls.Add(useSharedWorkbook, 0, 0);
            layout.SetColumnSpan(useSharedWorkbook, 3);

            workbookPath.Dock = DockStyle.Fill;
            browseWorkbookButton.Text = "Browse";
            browseWorkbookButton.AutoSize = true;
            browseWorkbookButton.Click += BrowseWorkbook;
            layout.Controls.Add(new Label { Text = "Workbook", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 1);
            layout.Controls.Add(workbookPath, 1, 1);
            layout.Controls.Add(browseWorkbookButton, 2, 1);

            checkWorkbookButton.Text = "Check";
            checkWorkbookButton.AutoSize = true;
            checkWorkbookButton.Click += CheckWorkbook;
            workbookStatus.AutoSize = true;
            workbookStatus.Anchor = AnchorStyles.Left;
            layout.Controls.Add(checkWorkbookButton, 1, 2);
            layout.Controls.Add(workbookStatus, 2, 2);

            Label explanation = new Label
            {
                AutoSize = true,
                MaximumSize = new Size(760, 0),
                Margin = new Padding(0, 16, 0, 0),
                Text = "Cabin Tools reads the locally cached PDM workbook without changing it. " +
                       "Use normal PDM checkout to edit the workbook, Get Latest on other computers, then click Sync in the task pane. " +
                       "The loader recognizes list columns by header and drawing mappings by Cabin type description, " +
                       "Cabin type defined, Layout type, and Drw Number."
            };
            layout.Controls.Add(explanation, 0, 3);
            layout.SetColumnSpan(explanation, 3);
            page.Controls.Add(layout);
            return page;
        }

        private TabPage BuildMappingTab()
        {
            TabPage page = new TabPage("Drawing map");
            mappings.Dock = DockStyle.Fill;
            mappings.AutoGenerateColumns = true;
            allowOverride.Text = "Allow manual drawing-number override";
            allowOverride.Dock = DockStyle.Top;
            page.Controls.Add(mappings);
            page.Controls.Add(allowOverride);
            return page;
        }

        private TabPage BuildDimensionTab()
        {
            TabPage page = new TabPage("Dimensions");
            dimensions.Dock = DockStyle.Fill;
            dimensions.AutoGenerateColumns = true;
            page.Controls.Add(dimensions);
            return page;
        }

        private void LoadProfile()
        {
            allowOverride.Checked = profile.AllowDrawingNumberOverride;
            useSharedWorkbook.Checked = profile.UseSharedWorkbook;
            workbookPath.Text = profile.SharedWorkbookPath ?? string.Empty;
            mappings.DataSource = new BindingList<DrawingNumberMap>(profile.DrawingNumberMappings);
            dimensions.DataSource = new BindingList<DimensionMap>(profile.Dimensions);
            catalogValues.Text = string.Join(Environment.NewLine,
                (profile.PropertyCatalog ?? new List<string>()).ToArray());
            documentKind.SelectedItem = PropertyPaneDocumentKind.Part;
            BindGroups();
            BindLists();
            UpdateWorkbookMode();
        }

        private void BindGroups()
        {
            PropertyPaneLayout layout = CurrentLayout();
            groups.DataSource = null;
            groups.DataSource = layout == null ? null : new BindingList<PropertyPaneGroup>(layout.Groups);
        }

        private void BindFields()
        {
            PropertyPaneGroup group = groups.SelectedItem as PropertyPaneGroup;
            fields.DataSource = group == null ? null : new BindingList<PropertyPaneField>(group.Fields);
        }

        private void BindLists()
        {
            listName.DataSource = null;
            listName.DataSource = profile.Lists;
            listName.DisplayMember = "Name";
            BindListValues();
        }

        private void BindListValues()
        {
            PropertyPaneNamedList selected = listName.SelectedItem as PropertyPaneNamedList;
            listValues.Text = selected == null ? string.Empty : string.Join(Environment.NewLine, selected.Values.ToArray());
        }

        private PropertyPaneLayout CurrentLayout()
        {
            if (!(documentKind.SelectedItem is PropertyPaneDocumentKind))
                return null;
            PropertyPaneDocumentKind kind = (PropertyPaneDocumentKind)documentKind.SelectedItem;
            return profile.Layouts.FirstOrDefault(l => l.DocumentKind == kind);
        }

        private void AddGroup(object sender, EventArgs e)
        {
            PropertyPaneLayout layout = CurrentLayout();
            if (layout == null)
                return;
            string label = TextEntryDialog.Ask(this, "Add group", "Group name:");
            if (string.IsNullOrWhiteSpace(label))
                return;
            layout.Groups.Add(new PropertyPaneGroup { Id = Slug(label), Label = label.Trim(), Order = layout.Groups.Count });
            BindGroups();
            groups.SelectedIndex = layout.Groups.Count - 1;
        }

        private void RemoveGroup(object sender, EventArgs e)
        {
            PropertyPaneLayout layout = CurrentLayout();
            PropertyPaneGroup group = groups.SelectedItem as PropertyPaneGroup;
            if (layout == null || group == null)
                return;
            if (MessageBox.Show(this, "Remove group '" + group.Label + "'?", "Cabin Tools",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                return;
            layout.Groups.Remove(group);
            Renumber(layout.Groups, g => g.Order, (g, i) => g.Order = i);
            BindGroups();
        }

        private void RenameGroup(object sender, EventArgs e)
        {
            PropertyPaneGroup group = groups.SelectedItem as PropertyPaneGroup;
            if (group == null)
                return;
            string label = TextEntryDialog.Ask(this, "Rename group", "Group name:", group.Label);
            if (string.IsNullOrWhiteSpace(label))
                return;
            group.Label = label.Trim();
            BindGroups();
        }

        private void MoveGroup(int direction)
        {
            PropertyPaneLayout layout = CurrentLayout();
            PropertyPaneGroup item = groups.SelectedItem as PropertyPaneGroup;
            if (layout == null || item == null)
                return;
            int index = layout.Groups.IndexOf(item);
            int target = index + direction;
            if (target < 0 || target >= layout.Groups.Count)
                return;
            layout.Groups.RemoveAt(index);
            layout.Groups.Insert(target, item);
            Renumber(layout.Groups, g => g.Order, (g, i) => g.Order = i);
            BindGroups();
            groups.SelectedIndex = target;
        }

        private void AddField(object sender, EventArgs e)
        {
            PropertyPaneGroup group = groups.SelectedItem as PropertyPaneGroup;
            if (group == null)
                return;
            using (CatalogFieldDialog dialog = new CatalogFieldDialog(profile.PropertyCatalog))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;
                group.Fields.Add(new PropertyPaneField
                {
                    Id = Slug(dialog.PropertyName),
                    Label = dialog.LabelText,
                    PropertyName = dialog.PropertyName,
                    Order = group.Fields.Count,
                    ControlType = PropertyPaneControlType.Text,
                    DefaultScope = PropertyPaneScope.Document,
                    Visible = true,
                    BlankMeansNoChange = true,
                    AllowExplicitClear = true,
                    AllowedScopes = new List<PropertyPaneScope> { PropertyPaneScope.Document,
                        PropertyPaneScope.ActiveConfiguration, PropertyPaneScope.SelectedConfigurations,
                        PropertyPaneScope.AllConfigurations }
                });
            }
            BindFields();
            if (fields.Rows.Count > 0)
            {
                fields.CurrentCell = fields.Rows[fields.Rows.Count - 1].Cells[0];
                EditField(null, EventArgs.Empty);
            }
        }

        private void EditField(object sender, EventArgs e)
        {
            PropertyPaneField field = fields.CurrentRow == null
                ? null
                : fields.CurrentRow.DataBoundItem as PropertyPaneField;
            if (field == null)
                return;
            PropertyPaneDocumentKind kind = (PropertyPaneDocumentKind)documentKind.SelectedItem;
            using (PropertyPaneFieldDialog dialog = new PropertyPaneFieldDialog(field, kind, profile.Lists))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;
            }
            BindFields();
        }

        private void RemoveField(object sender, EventArgs e)
        {
            PropertyPaneGroup group = groups.SelectedItem as PropertyPaneGroup;
            PropertyPaneField field = fields.CurrentRow == null ? null : fields.CurrentRow.DataBoundItem as PropertyPaneField;
            if (group == null || field == null)
                return;
            group.Fields.Remove(field);
            Renumber(group.Fields, f => f.Order, (f, i) => f.Order = i);
            BindFields();
        }

        private void MoveField(int direction)
        {
            PropertyPaneGroup group = groups.SelectedItem as PropertyPaneGroup;
            PropertyPaneField item = fields.CurrentRow == null ? null : fields.CurrentRow.DataBoundItem as PropertyPaneField;
            if (group == null || item == null)
                return;
            int index = group.Fields.IndexOf(item);
            int target = index + direction;
            if (target < 0 || target >= group.Fields.Count)
                return;
            group.Fields.RemoveAt(index);
            group.Fields.Insert(target, item);
            Renumber(group.Fields, f => f.Order, (f, i) => f.Order = i);
            BindFields();
            fields.Rows[target].Selected = true;
        }

        private void UpdateList(object sender, EventArgs e)
        {
            if (useSharedWorkbook.Checked)
                return;
            PropertyPaneNamedList selected = listName.SelectedItem as PropertyPaneNamedList;
            if (selected == null)
                return;
            selected.Values = listValues.Lines.Select(v => v.Trim()).Where(v => v.Length > 0)
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        private void AddList(object sender, EventArgs e)
        {
            string name = TextEntryDialog.Ask(this, "Add list", "List name:");
            if (string.IsNullOrWhiteSpace(name) || profile.Lists.Any(l => string.Equals(l.Name, name, StringComparison.OrdinalIgnoreCase)))
                return;
            profile.Lists.Add(new PropertyPaneNamedList { Name = name.Trim() });
            BindLists();
            listName.SelectedIndex = profile.Lists.Count - 1;
        }

        private void RemoveList(object sender, EventArgs e)
        {
            PropertyPaneNamedList selected = listName.SelectedItem as PropertyPaneNamedList;
            if (selected == null)
                return;
            profile.Lists.Remove(selected);
            BindLists();
        }

        private void SaveAndClose(object sender, EventArgs e)
        {
            UpdateList(null, EventArgs.Empty);
            fields.EndEdit();
            mappings.EndEdit();
            dimensions.EndEdit();
            profile.AllowDrawingNumberOverride = allowOverride.Checked;
            profile.UseSharedWorkbook = useSharedWorkbook.Checked;
            profile.SharedWorkbookPath = workbookPath.Text.Trim();
            profile.PropertyCatalog = catalogValues.Lines.Select(v => v.Trim())
                .Where(v => v.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            try
            {
                service.Save(profile);
                ProfileChanged = true;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Settings not saved",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BrowseWorkbook(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog
            {
                Filter = "Excel workbook (*.xlsx)|*.xlsx",
                CheckFileExists = true,
                Multiselect = false
            })
            {
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    workbookPath.Text = dialog.FileName;
                    workbookStatus.Text = string.Empty;
                }
            }
        }

        private void CheckWorkbook(object sender, EventArgs e)
        {
            try
            {
                PropertyPaneWorkbookLoadResult result = service.CheckSharedWorkbook(workbookPath.Text);
                workbookStatus.ForeColor = Color.DarkGreen;
                workbookStatus.Text = result.ListCount + " lists, " + result.MappingCount + " mappings";
            }
            catch (Exception ex)
            {
                workbookStatus.ForeColor = Color.DarkRed;
                workbookStatus.Text = ex.Message;
            }
        }

        private void UpdateWorkbookMode()
        {
            bool shared = useSharedWorkbook.Checked;
            workbookPath.Enabled = shared;
            browseWorkbookButton.Enabled = shared;
            checkWorkbookButton.Enabled = shared;
            listValues.ReadOnly = shared;
            if (listActions != null)
                listActions.Enabled = !shared;
            mappings.ReadOnly = shared;
            mappings.AllowUserToAddRows = !shared;
            mappings.AllowUserToDeleteRows = !shared;
            if (!shared)
            {
                workbookStatus.ForeColor = SystemColors.ControlText;
                workbookStatus.Text = "Local profile lists are active.";
            }
        }

        private void ImportProfile(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog { Filter = "Cabin Tools profile (*.xml)|*.xml|All files (*.*)|*.*" })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;
                try { profile = service.Import(dialog.FileName); LoadProfile(); ProfileChanged = true; }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "Import failed", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void ExportProfile(object sender, EventArgs e)
        {
            using (SaveFileDialog dialog = new SaveFileDialog { Filter = "Cabin Tools profile (*.xml)|*.xml", FileName = "PropertyPaneProfile.xml" })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;
                service.Export(profile, dialog.FileName);
            }
        }

        private void ResetProfile(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Reset the property-pane profile to built-in defaults? A backup will be created.",
                    "Cabin Tools", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                return;
            profile = service.Reset();
            LoadProfile();
            ProfileChanged = true;
        }

        private static DataGridView Grid()
        {
            return new DataGridView
            {
                AllowUserToAddRows = true,
                AllowUserToDeleteRows = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells,
                BackgroundColor = SystemColors.Window,
                RowHeadersVisible = false
            };
        }

        private void ConfigureFieldsGrid()
        {
            fields.AutoGenerateColumns = false;
            fields.Columns.Clear();
            fields.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Label",
                HeaderText = "Label",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                FillWeight = 35
            });
            fields.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "PropertyName",
                HeaderText = "SOLIDWORKS property",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                FillWeight = 35
            });
            fields.Columns.Add(new DataGridViewComboBoxColumn
            {
                DataPropertyName = "ControlType",
                HeaderText = "Control",
                DataSource = Enum.GetValues(typeof(PropertyPaneControlType)),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
            });
            fields.Columns.Add(new DataGridViewComboBoxColumn
            {
                DataPropertyName = "DefaultScope",
                HeaderText = "Default scope",
                DataSource = Enum.GetValues(typeof(PropertyPaneScope)),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
            });
            fields.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "Visible",
                HeaderText = "Show",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader
            });
            fields.CellDoubleClick += delegate { EditField(null, EventArgs.Empty); };
        }

        private static FlowLayoutPanel Toolbar(params Button[] buttons)
        {
            FlowLayoutPanel panel = new FlowLayoutPanel { Dock = DockStyle.Bottom, AutoSize = true, Padding = new Padding(3) };
            panel.Controls.AddRange(buttons);
            return panel;
        }

        private static Button Button(string text, EventHandler click)
        {
            return PropertyPaneUi.Button(text, click, false);
        }

        private static void Renumber<T>(IList<T> items, Func<T, int> read, Action<T, int> write)
        {
            for (int i = 0; i < items.Count; i++)
                write(items[i], i);
        }

        private static string Slug(string value)
        {
            return new string((value ?? "field").ToLowerInvariant().Select(c => char.IsLetterOrDigit(c) ? c : '-').ToArray()).Trim('-');
        }
    }

    internal sealed class PropertyPaneFieldDialog : Form
    {
        private readonly PropertyPaneField field;
        private readonly PropertyPaneDocumentKind documentKind;
        private readonly TextBox label = new TextBox();
        private readonly TextBox propertyName = new TextBox();
        private readonly ComboBox controlType = new ComboBox();
        private readonly ComboBox listName = new ComboBox();
        private readonly CheckedListBox scopes = new CheckedListBox();
        private readonly ComboBox defaultScope = new ComboBox();
        private readonly CheckBox visible = new CheckBox();
        private readonly CheckBox required = new CheckBox();
        private readonly CheckBox readOnly = new CheckBox();
        private readonly CheckBox blankNoChange = new CheckBox();
        private readonly CheckBox allowClear = new CheckBox();
        private readonly TextBox defaultValue = new TextBox();
        private readonly TextBox defaultExpression = new TextBox();
        private readonly TextBox automaticValue = new TextBox();
        private readonly NumericUpDown maxLength = new NumericUpDown();
        private readonly TextBox validationPattern = new TextBox();
        private readonly TextBox validationMessage = new TextBox();
        private readonly TextBox visibleWhenField = new TextBox();
        private readonly TextBox visibleWhenValue = new TextBox();
        private readonly TextBox enabledWhenField = new TextBox();
        private readonly TextBox enabledWhenValue = new TextBox();
        private readonly TextBox helpText = new TextBox();

        public PropertyPaneFieldDialog(PropertyPaneField target,
            PropertyPaneDocumentKind kind, IEnumerable<PropertyPaneNamedList> lists)
        {
            field = target;
            documentKind = kind;
            Text = "Field settings";
            StartPosition = FormStartPosition.CenterParent;
            MinimumSize = new Size(620, 620);
            Size = new Size(720, 720);
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            PropertyPaneUi.Apply(this);

            controlType.DropDownStyle = ComboBoxStyle.DropDownList;
            controlType.DataSource = Enum.GetValues(typeof(PropertyPaneControlType));
            controlType.SelectedIndexChanged += delegate { UpdateControlState(); };
            listName.DropDownStyle = ComboBoxStyle.DropDownList;
            listName.Items.Add(string.Empty);
            foreach (PropertyPaneNamedList list in lists ?? Enumerable.Empty<PropertyPaneNamedList>())
                listName.Items.Add(list.Name);

            scopes.CheckOnClick = true;
            scopes.Height = 84;
            foreach (PropertyPaneScope scope in Enum.GetValues(typeof(PropertyPaneScope)))
            {
                if (kind == PropertyPaneDocumentKind.Drawing && scope != PropertyPaneScope.Document)
                    continue;
                scopes.Items.Add(scope, target.AllowedScopes != null && target.AllowedScopes.Contains(scope));
            }
            scopes.ItemCheck += delegate { BeginInvoke(new MethodInvoker(UpdateDefaultScopes)); };
            defaultScope.DropDownStyle = ComboBoxStyle.DropDownList;

            visible.Text = "Show field";
            required.Text = "Required";
            readOnly.Text = "Read-only";
            blankNoChange.Text = "Blank means no change";
            allowClear.Text = "Allow explicit Clear";
            maxLength.Maximum = 100000;

            TabControl tabs = new TabControl { Dock = DockStyle.Fill };
            tabs.TabPages.Add(BuildBasicTab());
            tabs.TabPages.Add(BuildBehaviorTab());
            tabs.TabPages.Add(BuildRulesTab());

            FlowLayoutPanel footer = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 48,
                Padding = new Padding(8),
                FlowDirection = FlowDirection.RightToLeft
            };
            Button ok = PropertyPaneUi.Button("OK", null, true);
            ok.DialogResult = DialogResult.OK;
            Button cancel = PropertyPaneUi.Button("Cancel", null, false);
            cancel.DialogResult = DialogResult.Cancel;
            footer.Controls.Add(ok);
            footer.Controls.Add(cancel);
            Controls.Add(tabs);
            Controls.Add(footer);
            AcceptButton = ok;
            CancelButton = cancel;
            FormClosing += ValidateAndStore;

            LoadField();
        }

        private TabPage BuildBasicTab()
        {
            TableLayoutPanel table = FormTable();
            AddRow(table, "Label", label);
            AddRow(table, "SOLIDWORKS property", propertyName);
            AddRow(table, "Control", controlType);
            AddRow(table, "Dropdown list", listName);
            AddRow(table, "Allowed scopes", scopes);
            AddRow(table, "Default scope", defaultScope);
            FlowLayoutPanel checks = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true };
            checks.Controls.AddRange(new Control[] { visible, required, readOnly });
            AddRow(table, "State", checks);
            TabPage page = new TabPage("Field");
            page.Controls.Add(table);
            return page;
        }

        private TabPage BuildBehaviorTab()
        {
            TableLayoutPanel table = FormTable();
            FlowLayoutPanel blank = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true };
            blank.Controls.AddRange(new Control[] { blankNoChange, allowClear });
            AddRow(table, "Blank / clear", blank);
            AddRow(table, "Default value", defaultValue);
            AddRow(table, "Default expression", defaultExpression);
            AddRow(table, "Automatic value key", automaticValue);
            AddRow(table, "Maximum length", maxLength);
            AddRow(table, "Validation pattern", validationPattern);
            AddRow(table, "Validation message", validationMessage);
            helpText.Multiline = true;
            helpText.Height = 80;
            AddRow(table, "Tooltip", helpText);
            TabPage page = new TabPage("Behavior");
            page.Controls.Add(table);
            return page;
        }

        private TabPage BuildRulesTab()
        {
            TableLayoutPanel table = FormTable();
            AddRow(table, "Visible when field", visibleWhenField);
            AddRow(table, "Visible when value", visibleWhenValue);
            AddRow(table, "Enabled when field", enabledWhenField);
            AddRow(table, "Enabled when value", enabledWhenValue);
            Label note = new Label
            {
                AutoSize = true,
                MaximumSize = new Size(520, 0),
                Text = "Rules use another field's stable ID and an exact value. Leave both boxes blank for no rule."
            };
            AddRow(table, string.Empty, note);
            TabPage page = new TabPage("Rules");
            page.Controls.Add(table);
            return page;
        }

        private void LoadField()
        {
            label.Text = field.Label ?? string.Empty;
            propertyName.Text = field.PropertyName ?? string.Empty;
            controlType.SelectedItem = field.ControlType;
            listName.SelectedItem = field.ListName ?? string.Empty;
            if (listName.SelectedIndex < 0)
                listName.Text = field.ListName ?? string.Empty;
            visible.Checked = field.Visible;
            required.Checked = field.Required;
            readOnly.Checked = field.ReadOnly;
            blankNoChange.Checked = field.BlankMeansNoChange;
            allowClear.Checked = field.AllowExplicitClear;
            defaultValue.Text = field.DefaultValue ?? string.Empty;
            defaultExpression.Text = field.DefaultExpression ?? string.Empty;
            automaticValue.Text = field.AutomaticValue ?? string.Empty;
            maxLength.Value = Math.Max(maxLength.Minimum, Math.Min(maxLength.Maximum, field.MaxLength));
            validationPattern.Text = field.ValidationPattern ?? string.Empty;
            validationMessage.Text = field.ValidationMessage ?? string.Empty;
            visibleWhenField.Text = field.VisibleWhenFieldId ?? string.Empty;
            visibleWhenValue.Text = field.VisibleWhenValue ?? string.Empty;
            enabledWhenField.Text = field.EnabledWhenFieldId ?? string.Empty;
            enabledWhenValue.Text = field.EnabledWhenValue ?? string.Empty;
            helpText.Text = field.HelpText ?? string.Empty;
            UpdateDefaultScopes();
            defaultScope.SelectedItem = field.DefaultScope;
            if (defaultScope.SelectedIndex < 0 && defaultScope.Items.Count > 0)
                defaultScope.SelectedIndex = 0;
            UpdateControlState();
        }

        private void UpdateDefaultScopes()
        {
            PropertyPaneScope? selected = defaultScope.SelectedItem is PropertyPaneScope
                ? (PropertyPaneScope?)defaultScope.SelectedItem : null;
            defaultScope.Items.Clear();
            foreach (PropertyPaneScope scope in scopes.CheckedItems.Cast<PropertyPaneScope>())
                defaultScope.Items.Add(scope);
            if (selected.HasValue && defaultScope.Items.Contains(selected.Value))
                defaultScope.SelectedItem = selected.Value;
            else if (defaultScope.Items.Count > 0)
                defaultScope.SelectedIndex = 0;
        }

        private void UpdateControlState()
        {
            PropertyPaneControlType type = controlType.SelectedItem is PropertyPaneControlType
                ? (PropertyPaneControlType)controlType.SelectedItem
                : PropertyPaneControlType.Text;
            listName.Enabled = type == PropertyPaneControlType.List;
            bool computed = type == PropertyPaneControlType.Automatic ||
                            type == PropertyPaneControlType.ReadOnlyPreview ||
                            type == PropertyPaneControlType.ReadOnly;
            if (computed)
            {
                readOnly.Checked = true;
                allowClear.Checked = false;
            }
        }

        private void ValidateAndStore(object sender, FormClosingEventArgs e)
        {
            if (DialogResult != DialogResult.OK)
                return;
            List<PropertyPaneScope> allowed = scopes.CheckedItems.Cast<PropertyPaneScope>().ToList();
            string error = null;
            if (string.IsNullOrWhiteSpace(label.Text)) error = "A label is required.";
            else if (string.IsNullOrWhiteSpace(propertyName.Text)) error = "An exact SOLIDWORKS property name is required.";
            else if (allowed.Count == 0) error = "Select at least one allowed scope.";
            else if (!(defaultScope.SelectedItem is PropertyPaneScope)) error = "Select a default scope.";
            else if (documentKind == PropertyPaneDocumentKind.Drawing && allowed.Any(s => s != PropertyPaneScope.Document))
                error = "Drawing fields can use document scope only.";
            else if ((PropertyPaneControlType)controlType.SelectedItem == PropertyPaneControlType.List &&
                     string.IsNullOrWhiteSpace(Convert.ToString(listName.Text)))
                error = "Select a dropdown list for a list field.";

            if (error != null)
            {
                e.Cancel = true;
                MessageBox.Show(this, error, "Field settings", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            field.Label = label.Text.Trim();
            field.PropertyName = propertyName.Text.Trim();
            field.ControlType = (PropertyPaneControlType)controlType.SelectedItem;
            field.ListName = Convert.ToString(listName.Text).Trim();
            field.AllowedScopes = allowed;
            field.DefaultScope = (PropertyPaneScope)defaultScope.SelectedItem;
            field.Visible = visible.Checked;
            field.Required = required.Checked;
            field.ReadOnly = readOnly.Checked;
            field.BlankMeansNoChange = blankNoChange.Checked;
            field.AllowExplicitClear = allowClear.Checked && !readOnly.Checked;
            field.DefaultValue = defaultValue.Text;
            field.DefaultExpression = defaultExpression.Text;
            field.AutomaticValue = automaticValue.Text.Trim();
            field.MaxLength = Decimal.ToInt32(maxLength.Value);
            field.ValidationPattern = validationPattern.Text;
            field.ValidationMessage = validationMessage.Text;
            field.VisibleWhenFieldId = visibleWhenField.Text.Trim();
            field.VisibleWhenValue = visibleWhenValue.Text;
            field.EnabledWhenFieldId = enabledWhenField.Text.Trim();
            field.EnabledWhenValue = enabledWhenValue.Text;
            field.HelpText = helpText.Text;
        }

        private static TableLayoutPanel FormTable()
        {
            TableLayoutPanel table = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 2,
                Padding = new Padding(12)
            };
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 155));
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            return table;
        }

        private static void AddRow(TableLayoutPanel table, string caption, Control control)
        {
            int row = table.RowCount++;
            control.Dock = DockStyle.Fill;
            control.Margin = new Padding(3, 4, 3, 4);
            table.Controls.Add(new Label
            {
                Text = caption,
                AutoSize = true,
                Anchor = AnchorStyles.Left,
                Margin = new Padding(3, 8, 6, 3)
            }, 0, row);
            table.Controls.Add(control, 1, row);
        }
    }

    internal sealed class CatalogFieldDialog : Form
    {
        private readonly ComboBox property = new ComboBox();
        private readonly TextBox label = new TextBox();
        public string PropertyName { get { return Convert.ToString(property.Text).Trim(); } }
        public string LabelText { get { return label.Text.Trim(); } }

        public CatalogFieldDialog(IEnumerable<string> catalog)
        {
            Text = "Add field";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Size = new Size(420, 180);
            PropertyPaneUi.Apply(this);
            property.Dock = DockStyle.Top;
            property.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            property.AutoCompleteSource = AutoCompleteSource.ListItems;
            property.Items.AddRange((catalog ?? new string[0]).Cast<object>().ToArray());
            label.Dock = DockStyle.Top;
            property.TextChanged += delegate { if (string.IsNullOrWhiteSpace(label.Text)) label.Text = property.Text; };
            Button ok = PropertyPaneUi.Button("OK", null, true);
            ok.DialogResult = DialogResult.OK;
            Button cancel = PropertyPaneUi.Button("Cancel", null, false);
            cancel.DialogResult = DialogResult.Cancel;
            FlowLayoutPanel buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 42, FlowDirection = FlowDirection.RightToLeft };
            buttons.Controls.Add(ok); buttons.Controls.Add(cancel);
            Controls.Add(label); Controls.Add(new Label { Text = "Label", Dock = DockStyle.Top });
            Controls.Add(property); Controls.Add(new Label { Text = "Property", Dock = DockStyle.Top }); Controls.Add(buttons);
            AcceptButton = ok; CancelButton = cancel;
            FormClosing += delegate(object sender, FormClosingEventArgs e)
            {
                if (DialogResult == DialogResult.OK && (string.IsNullOrWhiteSpace(PropertyName) || string.IsNullOrWhiteSpace(LabelText)))
                { e.Cancel = true; MessageBox.Show(this, "Property and label are required.", "Cabin Tools"); }
            };
        }
    }

    internal sealed class TextEntryDialog : Form
    {
        private readonly TextBox input = new TextBox();
        private TextEntryDialog(string title, string prompt, string initialValue)
        {
            Text = title; StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
            Size = new Size(390, 150); MinimizeBox = false; MaximizeBox = false;
            input.Dock = DockStyle.Top;
            input.Text = initialValue ?? string.Empty;
            Button ok = PropertyPaneUi.Button("OK", null, true);
            ok.DialogResult = DialogResult.OK;
            Button cancel = PropertyPaneUi.Button("Cancel", null, false);
            cancel.DialogResult = DialogResult.Cancel;
            FlowLayoutPanel buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 42, FlowDirection = FlowDirection.RightToLeft };
            buttons.Controls.Add(ok); buttons.Controls.Add(cancel);
            Controls.Add(input); Controls.Add(new Label { Text = prompt, Dock = DockStyle.Top, Height = 24 }); Controls.Add(buttons);
            AcceptButton = ok; CancelButton = cancel;
            PropertyPaneUi.Apply(this);
        }
        public static string Ask(IWin32Window owner, string title, string prompt)
        {
            return Ask(owner, title, prompt, string.Empty);
        }
        public static string Ask(IWin32Window owner, string title, string prompt, string initialValue)
        {
            using (TextEntryDialog dialog = new TextEntryDialog(title, prompt, initialValue))
                return dialog.ShowDialog(owner) == DialogResult.OK ? dialog.input.Text : null;
        }
    }

    internal static class PropertyPaneUi
    {
        private static readonly Color Accent = Color.FromArgb(0, 103, 184);

        public static void Apply(Form form)
        {
            form.AutoScaleMode = AutoScaleMode.Dpi;
            form.Font = SystemFonts.MessageBoxFont;
            form.BackColor = Color.FromArgb(244, 246, 248);
            form.Shown += delegate { StyleTree(form); };
        }

        public static Button Button(string text, EventHandler click, bool primary)
        {
            Button button = new Button
            {
                Text = text,
                AutoSize = true,
                FlatStyle = FlatStyle.Flat,
                Padding = new Padding(7, 2, 7, 2),
                BackColor = primary ? Accent : Color.FromArgb(248, 249, 250),
                ForeColor = primary ? Color.White : SystemColors.ControlText
            };
            button.FlatAppearance.BorderColor = primary ? Accent : Color.FromArgb(190, 198, 206);
            button.FlatAppearance.BorderSize = primary ? 0 : 1;
            if (click != null)
                button.Click += click;
            return button;
        }

        private static void StyleTree(Control parent)
        {
            foreach (Control control in parent.Controls)
            {
                DataGridView grid = control as DataGridView;
                if (grid != null)
                {
                    grid.BackgroundColor = Color.White;
                    grid.BorderStyle = BorderStyle.FixedSingle;
                    grid.EnableHeadersVisualStyles = false;
                    grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(236, 240, 244);
                }
                StyleTree(control);
            }
        }
    }
}
