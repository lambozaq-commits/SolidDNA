using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace SolidDNA
{
    internal sealed class PropertyPaneReadValue
    {
        public string RawValue { get; set; }
        public string ResolvedValue { get; set; }
        public bool IsInherited { get; set; }
        public bool IsMixed { get; set; }
        public bool Exists { get; set; }
    }

    internal sealed class PropertyPaneEdit
    {
        public string FieldId { get; set; }
        public string PropertyName { get; set; }
        public PropertyPaneScope Scope { get; set; }
        public List<string> SelectedConfigurations { get; set; }
        public string Value { get; set; }
        public bool Clear { get; set; }
    }

    internal sealed class PropertyPaneApplyResult
    {
        public int Applied { get; set; }
        public int Skipped { get; set; }
        public bool RollbackAttempted { get; set; }
        public bool RollbackSucceeded { get; set; }
        public PropertyPaneRollbackToken RollbackToken { get; set; }
        public List<string> Errors { get; private set; }

        public PropertyPaneApplyResult()
        {
            Errors = new List<string>();
        }

        public string Summary
        {
            get
            {
                string text = "Updated " + Applied + ", skipped " + Skipped +
                    ", failed " + Errors.Count;
                if (RollbackAttempted)
                    text += RollbackSucceeded ? "; restored" : "; restoration incomplete";
                return text;
            }
        }
    }

    internal sealed class PropertyPaneRollbackToken
    {
        private readonly List<Action> actions = new List<Action>();
        private bool used;

        public bool HasChanges { get { return actions.Count > 0; } }

        public void Add(Action action)
        {
            if (action != null)
                actions.Add(action);
        }

        public bool RollBack(IList<string> errors)
        {
            if (used)
                return true;
            used = true;
            bool success = true;
            for (int i = actions.Count - 1; i >= 0; i--)
            {
                try { actions[i](); }
                catch (Exception ex)
                {
                    success = false;
                    errors.Add("Restoration failed: " + ex.Message);
                }
            }
            return success;
        }
    }

    internal sealed class PropertyPaneCoordinatedResult
    {
        public int Updated { get; set; }
        public int Skipped { get; set; }
        public bool RebuildSucceeded { get; set; }
        public bool RollbackAttempted { get; set; }
        public bool RollbackSucceeded { get; set; }
        public List<string> Errors { get; private set; }

        public PropertyPaneCoordinatedResult()
        {
            RebuildSucceeded = true;
            RollbackSucceeded = true;
            Errors = new List<string>();
        }

        public string Summary
        {
            get
            {
                string text = "Updated " + Updated + ", skipped " + Skipped +
                    ", failed " + Errors.Count;
                if (RollbackAttempted)
                    text += RollbackSucceeded ? "; restored" : "; restoration incomplete";
                return text + " (not saved)";
            }
        }
    }

    internal static class PropertyPaneApplyCoordinator
    {
        public static PropertyPaneCoordinatedResult Apply(IModelDoc2 model,
            IEnumerable<PropertyPaneEdit> propertyEdits,
            IEnumerable<DimensionEdit> dimensionEdits)
        {
            PropertyPaneCoordinatedResult combined = new PropertyPaneCoordinatedResult();
            PropertyPaneApplyResult properties = PropertyPanePropertyService.Apply(model, propertyEdits);
            if (properties.Errors.Count > 0)
            {
                Merge(combined, properties);
                return combined;
            }

            PropertyPaneApplyResult dimensions = PropertyPaneDimensionService.Apply(model, dimensionEdits);
            if (dimensions.Errors.Count > 0)
            {
                Restore(properties);
                Merge(combined, properties);
                Merge(combined, dimensions);
                return combined;
            }

            if (properties.Applied > 0 || dimensions.Applied > 0)
            {
                combined.RebuildSucceeded = model.ForceRebuild3(false);
                if (!combined.RebuildSucceeded)
                {
                    dimensions.Errors.Add("SOLIDWORKS reported a rebuild error.");
                    Restore(dimensions);
                    Restore(properties);
                    try { model.ForceRebuild3(false); }
                    catch (Exception ex)
                    {
                        dimensions.Errors.Add("Rebuild after restoration failed: " + ex.Message);
                    }
                }
            }

            Merge(combined, properties);
            Merge(combined, dimensions);
            PropertyPaneLogger.Write("Coordinated apply completed. " + combined.Summary);
            return combined;
        }

        private static void Restore(PropertyPaneApplyResult result)
        {
            if (result == null || result.RollbackToken == null || !result.RollbackToken.HasChanges)
                return;
            result.RollbackAttempted = true;
            result.RollbackSucceeded = result.RollbackToken.RollBack(result.Errors);
            if (result.RollbackSucceeded)
                result.Applied = 0;
        }

        private static void Merge(PropertyPaneCoordinatedResult target,
            PropertyPaneApplyResult source)
        {
            if (source == null)
                return;
            target.Updated += source.Applied;
            target.Skipped += source.Skipped;
            target.Errors.AddRange(source.Errors);
            if (source.RollbackAttempted)
            {
                target.RollbackAttempted = true;
                target.RollbackSucceeded = target.RollbackSucceeded && source.RollbackSucceeded;
            }
        }
    }

    internal static class PropertyPaneLogger
    {
        public static void Write(string message)
        {
            try
            {
                string folder = Path.Combine(
                    System.Environment.GetFolderPath(
                        System.Environment.SpecialFolder.ApplicationData),
                    "CabinTools", "Logs");
                Directory.CreateDirectory(folder);
                File.AppendAllText(Path.Combine(folder, "PropertyPane.log"),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " - " + message +
                    System.Environment.NewLine);
            }
            catch
            {
                // Logging must never interfere with SOLIDWORKS.
            }
        }
    }

    internal static class DrawingNumberResolver
    {
        public static bool TryResolve(PropertyPaneProfile profile, string cabinDescription,
            string cabinDefined, string layoutType, out string drawingNumber, out string reason)
        {
            drawingNumber = string.Empty;
            reason = string.Empty;

            List<DrawingNumberMap> matches = (profile.DrawingNumberMappings ?? new List<DrawingNumberMap>())
                .Where(m => Same(m.CabinDescription, cabinDescription) &&
                            Same(m.CabinDefined, cabinDefined) &&
                            Same(m.LayoutType, layoutType))
                .ToList();

            if (matches.Count == 0)
            {
                reason = "No drawing-number mapping matches the three drawing fields.";
                return false;
            }

            string[] numbers = matches.Select(m => (m.DrawingNumber ?? string.Empty).Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            if (numbers.Length != 1 || string.IsNullOrWhiteSpace(numbers[0]))
            {
                reason = "The drawing-number mapping is ambiguous.";
                return false;
            }

            drawingNumber = numbers[0];
            return true;
        }

        private static bool Same(string left, string right)
        {
            return string.Equals((left ?? string.Empty).Trim(), (right ?? string.Empty).Trim(),
                StringComparison.OrdinalIgnoreCase);
        }
    }

    internal static class PropertyPaneComputedValueService
    {
        public static string ReadModelValue(IModelDoc2 model, string key)
        {
            if (model == null)
                return string.Empty;
            if (string.Equals(key, "FileName", StringComparison.OrdinalIgnoreCase))
                return Path.GetFileNameWithoutExtension(model.GetPathName() ?? model.GetTitle());
            if (!string.Equals(key, "Weight", StringComparison.OrdinalIgnoreCase))
                return string.Empty;

            object rawMassProperty = null;
            try
            {
                IModelDocExtension extension = model.Extension;
                if (extension == null)
                    return string.Empty;
                rawMassProperty = extension.CreateMassProperty2();
                IMassProperty2 massProperty = rawMassProperty as IMassProperty2;
                if (massProperty == null)
                    return string.Empty;
                double kilograms = massProperty.Mass;
                return double.IsNaN(kilograms) || double.IsInfinity(kilograms)
                    ? string.Empty
                    : kilograms.ToString("0.###", CultureInfo.CurrentCulture) + " kg";
            }
            catch (Exception ex)
            {
                PropertyPaneLogger.Write("Computed Weight read failed. " + ex.Message);
                return string.Empty;
            }
            finally
            {
                if (rawMassProperty != null && Marshal.IsComObject(rawMassProperty))
                {
                    try { Marshal.FinalReleaseComObject(rawMassProperty); }
                    catch { }
                }
            }
        }
    }

    internal static class PropertyPanePropertyService
    {
        private sealed class PropertySnapshot
        {
            public ICustomPropertyManager Manager { get; set; }
            public string Name { get; set; }
            public bool Existed { get; set; }
            public string Value { get; set; }
            public int Type { get; set; }
            public string Scope { get; set; }
        }

        private sealed class PlannedPropertyWrite
        {
            public PropertyPaneEdit Edit { get; set; }
            public string Target { get; set; }
            public PropertySnapshot Snapshot { get; set; }
        }

        public static string[] GetConfigurationNames(IModelDoc2 model)
        {
            if (!CabinCustomPropertyStore.SupportsConfigurationProperties(model))
                return new string[0];

            object names = model.GetConfigurationNames();
            object[] items = names as object[];
            if (items != null)
                return items.Select(i => Convert.ToString(i, CultureInfo.InvariantCulture))
                    .Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();

            string[] strings = names as string[];
            return strings ?? new string[0];
        }

        public static PropertyPaneReadValue Read(IModelDoc2 model, string propertyName,
            PropertyPaneScope scope, IList<string> selectedConfigurations)
        {
            List<string> targets;
            List<CabinCustomPropertyValue> values;
            try
            {
                targets = ResolveTargets(model, scope, selectedConfigurations);
                values = targets.Select(t => ReadFromManager(model, propertyName, t)).ToList();
            }
            catch (Exception ex)
            {
                PropertyPaneLogger.Write("Property read failed. Document: " + DocumentIdentity(model) +
                    ". Property: " + propertyName + ". Scope: " + scope + ". " + ex.Message);
                throw;
            }

            string[] rawValues = values.Select(v => (v.RawValue ?? string.Empty).Trim())
                .Distinct(StringComparer.Ordinal).ToArray();
            string[] resolvedValues = values.Select(v => string.IsNullOrWhiteSpace(v.ResolvedValue)
                    ? (v.RawValue ?? string.Empty).Trim()
                    : v.ResolvedValue.Trim())
                .Distinct(StringComparer.Ordinal).ToArray();

            return new PropertyPaneReadValue
            {
                RawValue = rawValues.Length == 1 ? rawValues[0] : "<varies>",
                ResolvedValue = resolvedValues.Length == 1 ? resolvedValues[0] : "<varies>",
                IsMixed = rawValues.Length > 1 || resolvedValues.Length > 1,
                Exists = values.All(v => v.Exists)
            };
        }

        public static PropertyPaneReadValue ReadDescriptionEffective(IModelDoc2 model,
            PropertyPaneScope scope, IList<string> selectedConfigurations)
        {
            if (scope == PropertyPaneScope.Document)
                return Read(model, CabinCustomPropertyStore.DescriptionPropertyName, scope, selectedConfigurations);

            CabinCustomPropertyValue document = ReadFromManager(model,
                CabinCustomPropertyStore.DescriptionPropertyName, string.Empty);
            string documentEffective = string.IsNullOrWhiteSpace(document.ResolvedValue)
                ? document.RawValue ?? string.Empty : document.ResolvedValue;
            List<CabinCustomPropertyValue> configurationValues = ResolveTargets(model, scope, selectedConfigurations)
                .Select(t => ReadFromManager(model, CabinCustomPropertyStore.DescriptionPropertyName, t)).ToList();
            List<string> raw = configurationValues.Select(v => (v.RawValue ?? string.Empty).Trim()).ToList();
            bool inherited = raw.Any(string.IsNullOrWhiteSpace);
            string[] effective = configurationValues.Select(v =>
            {
                string configurationValue = string.IsNullOrWhiteSpace(v.ResolvedValue)
                    ? v.RawValue ?? string.Empty : v.ResolvedValue;
                return string.IsNullOrWhiteSpace(v.RawValue)
                    ? documentEffective.Trim() : configurationValue.Trim();
            }).Distinct(StringComparer.Ordinal).ToArray();
            string[] rawDistinct = raw.Distinct(StringComparer.Ordinal).ToArray();

            return new PropertyPaneReadValue
            {
                RawValue = rawDistinct.Length == 1 ? rawDistinct[0] : "<varies>",
                ResolvedValue = effective.Length == 1 ? effective[0] : "<varies>",
                IsInherited = inherited,
                IsMixed = effective.Length > 1,
                Exists = configurationValues.All(v => v.Exists)
            };
        }

        public static PropertyPaneApplyResult Apply(IModelDoc2 model, IEnumerable<PropertyPaneEdit> edits)
        {
            PropertyPaneApplyResult result = new PropertyPaneApplyResult();
            List<PropertyPaneEdit> requested = (edits ?? Enumerable.Empty<PropertyPaneEdit>()).ToList();
            PropertyPaneRollbackToken rollback = new PropertyPaneRollbackToken();
            result.RollbackToken = rollback;

            CabinCustomPropertyStore.EnsureCanWrite(model);
            try
            {
                List<PlannedPropertyWrite> plan = new List<PlannedPropertyWrite>();
                foreach (PropertyPaneEdit edit in requested)
                {
                    if (edit == null || string.IsNullOrWhiteSpace(edit.PropertyName))
                        throw new InvalidOperationException("A property edit has no property name.");
                    foreach (string target in ResolveTargets(model, edit.Scope, edit.SelectedConfigurations))
                    {
                        ICustomPropertyManager manager = GetManager(model, target);
                        PropertySnapshot snapshot = Capture(manager, edit.PropertyName);
                        snapshot.Scope = ScopeName(target);
                        plan.Add(new PlannedPropertyWrite { Edit = edit, Target = target, Snapshot = snapshot });
                    }
                }

                foreach (PlannedPropertyWrite item in plan)
                {
                    PropertyPaneEdit edit = item.Edit;
                    PropertySnapshot snapshot = item.Snapshot;
                    if (edit.Clear)
                    {
                        if (snapshot.Existed)
                        {
                            AddRestoreAction(rollback, snapshot);
                            int deleteResult = snapshot.Manager.Delete2(edit.PropertyName);
                            if (deleteResult != (int)swCustomInfoDeleteResult_e.swCustomInfoDeleteResult_OK)
                                throw new InvalidOperationException("Could not clear '" + edit.PropertyName + "' in " + snapshot.Scope +
                                    " (status " + deleteResult + ").");
                        }
                        else
                        {
                            result.Skipped++;
                            continue;
                        }
                    }
                    else
                    {
                        if (snapshot.Existed && string.Equals(snapshot.Value ?? string.Empty,
                                edit.Value ?? string.Empty, StringComparison.Ordinal))
                        {
                            result.Skipped++;
                            continue;
                        }
                        AddRestoreAction(rollback, snapshot);
                        int type = snapshot.Existed && snapshot.Type > 0
                            ? snapshot.Type
                            : (int)swCustomInfoType_e.swCustomInfoText;
                        int addResult = snapshot.Manager.Add3(edit.PropertyName, type, edit.Value ?? string.Empty,
                            (int)swCustomPropertyAddOption_e.swCustomPropertyReplaceValue);
                        if (addResult != (int)swCustomInfoAddResult_e.swCustomInfoAddResult_AddedOrChanged)
                            throw new InvalidOperationException("Could not write '" + edit.PropertyName + "' in " + snapshot.Scope +
                                " (status " + addResult + ").");
                    }

                    result.Applied++;
                }
            }
            catch (Exception ex)
            {
                result.Errors.Add(ex.Message);
                result.RollbackAttempted = rollback.HasChanges;
                result.RollbackSucceeded = !rollback.HasChanges || rollback.RollBack(result.Errors);
                if (result.RollbackSucceeded)
                    result.Applied = 0;
                PropertyPaneLogger.Write("Property apply failed. Document: " + DocumentIdentity(model) +
                    ". " + result.Summary + ". " + string.Join(" ", result.Errors.ToArray()));
                return result;
            }

            PropertyPaneLogger.Write("Property apply succeeded. Document: " + DocumentIdentity(model) +
                ". " + result.Summary);
            return result;
        }

        private static void AddRestoreAction(PropertyPaneRollbackToken rollback, PropertySnapshot snapshot)
        {
            rollback.Add(delegate
            {
                if (!snapshot.Existed)
                {
                    int deleteResult = snapshot.Manager.Delete2(snapshot.Name);
                    if (deleteResult != (int)swCustomInfoDeleteResult_e.swCustomInfoDeleteResult_OK &&
                        deleteResult != (int)swCustomInfoDeleteResult_e.swCustomInfoDeleteResult_NotPresent)
                        throw new InvalidOperationException("Could not remove newly created '" + snapshot.Name +
                            "' from " + snapshot.Scope + " (status " + deleteResult + ").");
                }
                else
                {
                    int type = snapshot.Type > 0 ? snapshot.Type : (int)swCustomInfoType_e.swCustomInfoText;
                    int addResult = snapshot.Manager.Add3(snapshot.Name, type, snapshot.Value ?? string.Empty,
                        (int)swCustomPropertyAddOption_e.swCustomPropertyReplaceValue);
                    if (addResult != (int)swCustomInfoAddResult_e.swCustomInfoAddResult_AddedOrChanged)
                        throw new InvalidOperationException("Could not restore '" + snapshot.Name + "' in " +
                            snapshot.Scope + " (status " + addResult + ").");
                }
            });
        }

        private static PropertySnapshot Capture(ICustomPropertyManager manager, string name)
        {
            string raw;
            string resolved;
            bool wasResolved;
            bool linked;
            int getResult = manager.Get6(name, false, out raw, out resolved, out wasResolved, out linked);
            return new PropertySnapshot
            {
                Manager = manager,
                Name = name,
                // swCustomInfoGetResult_NotPresent is 1. Cached (0) and
                // resolved (2) both mean that the property exists.
                Existed = getResult != 1,
                Value = raw ?? string.Empty,
                Type = manager.GetType2(name)
            };
        }

        private static CabinCustomPropertyValue ReadFromManager(IModelDoc2 model, string name, string configuration)
        {
            ICustomPropertyManager manager = GetManager(model, configuration);
            string raw;
            string resolved;
            bool wasResolved;
            bool linked;
            int getResult = manager.Get6(name, false, out raw, out resolved, out wasResolved, out linked);
            return new CabinCustomPropertyValue
            {
                Name = name,
                ScopeName = ScopeName(configuration),
                RawValue = raw ?? string.Empty,
                ResolvedValue = resolved ?? string.Empty,
                WasResolved = wasResolved,
                IsLinked = linked,
                Type = manager.GetType2(name),
                Exists = getResult != (int)swCustomInfoGetResult_e.swCustomInfoGetResult_NotPresent
            };
        }

        private static ICustomPropertyManager GetManager(IModelDoc2 model, string configuration)
        {
            IModelDocExtension extension = model == null ? null : model.Extension;
            if (extension == null)
                throw new InvalidOperationException("Could not access the SOLIDWORKS document extension.");
            ICustomPropertyManager manager = extension.CustomPropertyManager[configuration ?? string.Empty];
            if (manager == null)
                throw new InvalidOperationException("Could not access " + ScopeName(configuration) + ".");
            return manager;
        }

        private static List<string> ResolveTargets(IModelDoc2 model, PropertyPaneScope scope,
            IList<string> selectedConfigurations)
        {
            if (scope == PropertyPaneScope.Document)
                return new List<string> { string.Empty };
            if (!CabinCustomPropertyStore.SupportsConfigurationProperties(model))
                throw new InvalidOperationException("Configuration scope is available only for parts and assemblies.");

            if (scope == PropertyPaneScope.ActiveConfiguration)
            {
                string active = CabinCustomPropertyStore.GetActiveConfigurationName(model);
                if (string.IsNullOrWhiteSpace(active))
                    throw new InvalidOperationException("The active configuration could not be determined.");
                return new List<string> { active };
            }

            string[] available = GetConfigurationNames(model);
            if (scope == PropertyPaneScope.AllConfigurations)
            {
                if (available.Length == 0)
                    throw new InvalidOperationException("The document contains no configurations.");
                return available.ToList();
            }

            HashSet<string> valid = new HashSet<string>(available, StringComparer.OrdinalIgnoreCase);
            List<string> requested = (selectedConfigurations ?? new string[0])
                .Where(s => !string.IsNullOrWhiteSpace(s)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            List<string> missing = requested.Where(s => !valid.Contains(s)).ToList();
            if (missing.Count > 0)
                throw new InvalidOperationException("Configuration not found: " + string.Join(", ", missing.ToArray()) + ".");
            List<string> selected = requested.Where(s => valid.Contains(s)).ToList();
            if (selected.Count == 0)
                throw new InvalidOperationException("Select at least one configuration.");
            return selected;
        }

        private static string ScopeName(string configuration)
        {
            return string.IsNullOrWhiteSpace(configuration)
                ? "document properties"
                : "configuration '" + configuration + "'";
        }

        private static string DocumentIdentity(IModelDoc2 model)
        {
            if (model == null)
                return "<none>";
            string path = model.GetPathName();
            return string.IsNullOrWhiteSpace(path) ? model.GetTitle() : path;
        }
    }

    internal sealed class DimensionEdit
    {
        public DimensionMap Map { get; set; }
        public double Millimetres { get; set; }
        public PropertyPaneScope Scope { get; set; }
        public List<string> SelectedConfigurations { get; set; }
    }

    internal static class PropertyPaneDimensionService
    {
        private const int ThisConfiguration = 1;
        private const int AllConfigurations = 2;
        private const int SpecificConfigurations = 3;
        private const int SetValueSuccessful = 0;

        private sealed class DimensionSnapshot
        {
            public IDimension Dimension { get; set; }
            public string[] Configurations { get; set; }
            public double[] Values { get; set; }
            public string Label { get; set; }
        }

        private sealed class PlannedDimensionWrite
        {
            public DimensionEdit Edit { get; set; }
            public DimensionSnapshot Snapshot { get; set; }
            public int Option { get; set; }
            public object Names { get; set; }
        }

        public static bool HasDesignTable(IModelDoc2 model)
        {
            if (model == null || model.GetType() != (int)swDocumentTypes_e.swDocPART)
                return false;
            try { return model.GetDesignTable() != null; }
            catch { return false; }
        }

        public static bool TryReadMillimetres(IModelDoc2 model, DimensionMap map,
            out double millimetres, out string error)
        {
            bool mixed;
            return TryReadMillimetres(model, map, PropertyPaneScope.ActiveConfiguration,
                null, out millimetres, out mixed, out error);
        }

        public static bool TryReadMillimetres(IModelDoc2 model, DimensionMap map,
            PropertyPaneScope scope, IList<string> selectedConfigurations,
            out double millimetres, out bool mixed, out string error)
        {
            millimetres = 0;
            mixed = false;
            error = string.Empty;
            try
            {
                string[] targets = ResolveTargetConfigurations(model, scope, selectedConfigurations);
                IDimension dimension = FindDimension(model, map, targets);
                double[] values = ReadValues(dimension, targets);
                if (values.Length == 0)
                    throw new InvalidOperationException("No dimension value was returned for " + map.Label + ".");
                mixed = values.Any(v => Math.Abs(v - values[0]) > 0.000000001);
                millimetres = values[0] * 1000.0;
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                string document = model == null ? "<none>" : model.GetPathName();
                if (string.IsNullOrWhiteSpace(document) && model != null)
                    document = model.GetTitle();
                PropertyPaneLogger.Write("Dimension read/discovery failed. Document: " + document +
                    ". Feature: " + (map == null ? "<none>" : map.FeatureName) +
                    ". Scope: " + scope + ". " + ex.Message);
                return false;
            }
        }

        public static PropertyPaneApplyResult Apply(IModelDoc2 model, IEnumerable<DimensionEdit> edits)
        {
            PropertyPaneApplyResult result = new PropertyPaneApplyResult();
            CabinCustomPropertyStore.EnsureCanWrite(model);
            PropertyPaneRollbackToken rollback = new PropertyPaneRollbackToken();
            result.RollbackToken = rollback;

            try
            {
                List<PlannedDimensionWrite> plan = new List<PlannedDimensionWrite>();
                foreach (DimensionEdit edit in edits ?? Enumerable.Empty<DimensionEdit>())
                {
                    if (edit == null || edit.Map == null)
                        continue;
                    if (double.IsNaN(edit.Millimetres) || double.IsInfinity(edit.Millimetres))
                        throw new InvalidOperationException(edit.Map.Label + " must be a finite number.");
                    if (!edit.Map.AllowNegative && edit.Millimetres <= 0)
                        throw new InvalidOperationException(edit.Map.Label + " must be greater than 0 mm.");

                    string[] targets = ResolveTargetConfigurations(model, edit.Scope, edit.SelectedConfigurations);
                    IDimension dimension = FindDimension(model, edit.Map, targets);
                    double[] original = ReadValues(dimension, targets);
                    if (original.Length != targets.Length)
                        throw new InvalidOperationException("SOLIDWORKS did not return one " + edit.Map.Label +
                            " value for every target configuration.");
                    if (original.All(v => Math.Abs(v - edit.Millimetres / 1000.0) <= 0.000000001))
                    {
                        result.Skipped++;
                        continue;
                    }

                    int option;
                    object names;
                    ResolveSetScope(model, edit.Scope, edit.SelectedConfigurations, out option, out names);
                    plan.Add(new PlannedDimensionWrite
                    {
                        Edit = edit,
                        Option = option,
                        Names = names,
                        Snapshot = new DimensionSnapshot
                        {
                            Dimension = dimension,
                            Configurations = targets,
                            Values = original,
                            Label = edit.Map.Label
                        }
                    });
                }

                foreach (PlannedDimensionWrite item in plan)
                {
                    AddDimensionRestoreAction(rollback, item.Snapshot);
                    int status = item.Snapshot.Dimension.SetSystemValue3(
                        item.Edit.Millimetres / 1000.0, item.Option, item.Names);
                    if (status != SetValueSuccessful)
                        throw new InvalidOperationException(item.Edit.Map.Label +
                            " returned SOLIDWORKS status " + SetValueStatusName(status) + ".");
                    result.Applied++;
                }
            }
            catch (Exception ex)
            {
                result.Errors.Add(ex.Message);
                result.RollbackAttempted = rollback.HasChanges;
                result.RollbackSucceeded = !rollback.HasChanges || rollback.RollBack(result.Errors);
                if (result.RollbackSucceeded)
                    result.Applied = 0;
            }

            string document = model == null ? "<none>" : model.GetPathName();
            if (string.IsNullOrWhiteSpace(document) && model != null)
                document = model.GetTitle();
            PropertyPaneLogger.Write("Dimension apply completed. Document: " + document + ". " +
                result.Summary + (result.Errors.Count == 0 ? string.Empty : ". " +
                string.Join(" ", result.Errors.ToArray())));
            return result;
        }

        private static void AddDimensionRestoreAction(PropertyPaneRollbackToken rollback,
            DimensionSnapshot snapshot)
        {
            rollback.Add(delegate
            {
                int count = Math.Min(snapshot.Configurations.Length, snapshot.Values.Length);
                for (int i = 0; i < count; i++)
                {
                    int status = snapshot.Dimension.SetSystemValue3(
                        snapshot.Values[i], SpecificConfigurations,
                        new[] { snapshot.Configurations[i] });
                    if (status != SetValueSuccessful)
                        throw new InvalidOperationException("Could not restore " + snapshot.Label +
                            " in configuration '" + snapshot.Configurations[i] +
                            "' (status " + SetValueStatusName(status) + ").");
                }
            });
        }

        private static IDimension FindDimension(IModelDoc2 model, DimensionMap map,
            string[] configurations)
        {
            if (model == null || model.GetType() != (int)swDocumentTypes_e.swDocPART)
                throw new InvalidOperationException("Cabin dimensions are available only in part documents.");

            IFeature feature = FindFeatureByName(model, map.FeatureName);
            if (feature == null)
                throw new InvalidOperationException("Required reference plane '" + map.FeatureName + "' was not found.");
            if (!string.Equals(feature.GetTypeName2(), "RefPlane", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Feature '" + map.FeatureName + "' is not a reference plane.");

            IFeature fromPlane = FindFeatureByName(model, map.FromPlane);
            if (fromPlane == null)
                throw new InvalidOperationException("Required reference plane '" + map.FromPlane + "' was not found.");
            if (!string.Equals(fromPlane.GetTypeName2(), "RefPlane", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Feature '" + map.FromPlane + "' is not a reference plane.");

            EnsureNotSuppressed(feature, configurations, map.FeatureName);
            ValidatePlaneDefinition(model, feature, fromPlane, map);

            IDisplayDimension display = feature.GetFirstDisplayDimension() as IDisplayDimension;
            IDimension dimension = display == null ? null : display.GetDimension2(0) as IDimension;
            if (dimension == null)
                throw new InvalidOperationException("Reference plane '" + map.FeatureName + "' has no editable offset dimension.");
            return dimension;
        }

        private static IFeature FindFeatureByName(IModelDoc2 model, string featureName)
        {
            if (model == null || string.IsNullOrWhiteSpace(featureName))
                return null;
            IFeature feature = model.FirstFeature() as IFeature;
            while (feature != null)
            {
                if (string.Equals(feature.Name ?? string.Empty, featureName,
                        StringComparison.Ordinal))
                    return feature;
                feature = feature.GetNextFeature() as IFeature;
            }
            return null;
        }

        private static void EnsureNotSuppressed(IFeature feature, string[] configurations,
            string featureName)
        {
            object raw = feature.IsSuppressed2(
                (int)swInConfigurationOpts_e.swSpecifyConfiguration, configurations);
            Array values = raw as Array;
            if (values == null)
                return;
            int index = 0;
            foreach (object item in values)
            {
                if (Convert.ToBoolean(item, CultureInfo.InvariantCulture))
                {
                    string configuration = index < configurations.Length
                        ? configurations[index] : "target configuration";
                    throw new InvalidOperationException("Reference plane '" + featureName +
                        "' is suppressed in configuration '" + configuration + "'.");
                }
                index++;
            }
        }

        private static void ValidatePlaneDefinition(IModelDoc2 model, IFeature feature,
            IFeature fromPlane, DimensionMap map)
        {
            IRefPlaneFeatureData definition = feature.GetDefinition() as IRefPlaneFeatureData;
            if (definition == null)
                throw new InvalidOperationException("Reference plane '" + map.FeatureName +
                    "' has no editable reference-plane definition.");
            bool accessed = false;
            try
            {
                accessed = definition.AccessSelections(model, null);
                if (!accessed)
                    throw new InvalidOperationException("Could not inspect reference plane '" + map.FeatureName + "'.");

                int type = definition.Type2;
                int constraint = definition.Constraint[(int)swRefPlaneReferenceIndex_e.swRefPlaneReference_First];
                bool distanceDefinition = type == (int)swRefPlaneType_e.swRefPlaneDistance ||
                    (constraint & (int)swRefPlaneReferenceConstraints_e.swRefPlaneReferenceConstraint_Distance) != 0;
                if (!distanceDefinition)
                    throw new InvalidOperationException("Reference plane '" + map.FeatureName +
                        "' is not an offset/distance plane.");

                object reference = definition.Reference[(int)swRefPlaneReferenceIndex_e.swRefPlaneReference_First];
                object expected = fromPlane.GetSpecificFeature2();
                if (reference == null || expected == null || !SameComObject(reference, expected))
                    throw new InvalidOperationException("Reference plane '" + map.FeatureName +
                        "' is not offset from configured plane '" + map.FromPlane + "'.");
            }
            finally
            {
                if (accessed)
                    definition.ReleaseSelectionAccess();
            }
        }

        private static bool SameComObject(object left, object right)
        {
            IntPtr leftPointer = IntPtr.Zero;
            IntPtr rightPointer = IntPtr.Zero;
            try
            {
                leftPointer = Marshal.GetIUnknownForObject(left);
                rightPointer = Marshal.GetIUnknownForObject(right);
                return leftPointer == rightPointer;
            }
            finally
            {
                if (leftPointer != IntPtr.Zero) Marshal.Release(leftPointer);
                if (rightPointer != IntPtr.Zero) Marshal.Release(rightPointer);
            }
        }

        private static string SetValueStatusName(int status)
        {
            return Enum.IsDefined(typeof(swSetValueReturnStatus_e), status)
                ? ((swSetValueReturnStatus_e)status).ToString()
                : status.ToString(CultureInfo.InvariantCulture);
        }

        private static void ResolveSetScope(IModelDoc2 model, PropertyPaneScope scope,
            IList<string> selectedConfigurations, out int option, out object names)
        {
            names = null;
            if (scope == PropertyPaneScope.AllConfigurations)
            {
                option = AllConfigurations;
                return;
            }
            if (scope == PropertyPaneScope.ActiveConfiguration)
            {
                option = ThisConfiguration;
                return;
            }
            if (scope != PropertyPaneScope.SelectedConfigurations)
                throw new InvalidOperationException("Dimensions require Active, Selected, or All configurations.");

            string[] available = PropertyPanePropertyService.GetConfigurationNames(model);
            HashSet<string> valid = new HashSet<string>(available, StringComparer.OrdinalIgnoreCase);
            string[] selected = (selectedConfigurations ?? new string[0])
                .Where(s => valid.Contains(s)).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            if (selected.Length == 0)
                throw new InvalidOperationException("Select at least one configuration for dimensions.");
            option = SpecificConfigurations;
            names = selected;
        }

        private static string[] ResolveTargetConfigurations(IModelDoc2 model,
            PropertyPaneScope scope, IList<string> selectedConfigurations)
        {
            string[] available = PropertyPanePropertyService.GetConfigurationNames(model);
            if (scope == PropertyPaneScope.ActiveConfiguration)
            {
                string active = CabinCustomPropertyStore.GetActiveConfigurationName(model);
                if (string.IsNullOrWhiteSpace(active))
                    throw new InvalidOperationException("The active configuration could not be determined.");
                return new[] { active };
            }
            if (scope == PropertyPaneScope.AllConfigurations)
            {
                if (available.Length == 0)
                    throw new InvalidOperationException("The part contains no configurations.");
                return available;
            }
            if (scope != PropertyPaneScope.SelectedConfigurations)
                throw new InvalidOperationException("Dimensions require Active, Selected, or All configurations.");

            HashSet<string> valid = new HashSet<string>(available, StringComparer.OrdinalIgnoreCase);
            string[] requested = (selectedConfigurations ?? new string[0])
                .Where(s => !string.IsNullOrWhiteSpace(s)).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            string[] missing = requested.Where(s => !valid.Contains(s)).ToArray();
            if (missing.Length > 0)
                throw new InvalidOperationException("Configuration not found: " + string.Join(", ", missing) + ".");
            string[] selected = requested.Where(s => valid.Contains(s)).ToArray();
            if (selected.Length == 0)
                throw new InvalidOperationException("Select at least one configuration for dimensions.");
            return selected;
        }

        private static double[] ReadValues(IDimension dimension, string[] configurations)
        {
            object raw = dimension.GetSystemValue3(SpecificConfigurations, configurations);
            Array array = raw as Array;
            if (array != null)
            {
                List<double> values = new List<double>();
                foreach (object item in array)
                    values.Add(Convert.ToDouble(item, CultureInfo.InvariantCulture));
                return values.ToArray();
            }

            if (raw != null)
                return new[] { Convert.ToDouble(raw, CultureInfo.InvariantCulture) };
            return new double[0];
        }
    }
}
