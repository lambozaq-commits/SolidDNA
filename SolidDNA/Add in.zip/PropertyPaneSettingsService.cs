using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Serialization;

namespace SolidDNA
{
    internal sealed class PropertyPaneSettingsService
    {
        private const string FileName = "PropertyPaneProfile.xml";
        private readonly XmlSerializer serializer = new XmlSerializer(typeof(PropertyPaneProfile));
        private readonly PropertyPaneWorkbookService workbookService = new PropertyPaneWorkbookService();

        public bool SharedWorkbookLoaded { get; private set; }
        public string SharedWorkbookStatus { get; private set; }

        public string SettingsFolder
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "CabinTools",
                    "Settings");
            }
        }

        public string ProfilePath
        {
            get { return Path.Combine(SettingsFolder, FileName); }
        }

        public PropertyPaneProfile Load()
        {
            Directory.CreateDirectory(SettingsFolder);

            PropertyPaneProfile profile;

            if (!File.Exists(ProfilePath))
            {
                profile = PropertyPaneDefaults.Create();
                Save(profile);
            }
            else
            {
                try
                {
                    bool migrated;
                    using (FileStream stream = File.OpenRead(ProfilePath))
                    {
                        profile = serializer.Deserialize(stream) as PropertyPaneProfile;
                        migrated = Migrate(profile);
                        Normalize(profile);
                        Validate(profile);
                    }
                    if (migrated)
                    {
                        Backup("before-migration");
                        Save(profile);
                        PropertyPaneLogger.Write("Property-pane profile migrated to schema " +
                            PropertyPaneDefaults.CurrentSchemaVersion + ".");
                    }
                }
                catch (Exception ex)
                {
                    string backup = Backup("invalid");
                    PropertyPaneLogger.Write("Settings load failed; defaults restored. " + ex.Message + " Backup: " + backup);
                    profile = PropertyPaneDefaults.Create();
                    Save(profile);
                }
            }

            ApplySharedWorkbook(profile);
            return profile;
        }

        public PropertyPaneWorkbookLoadResult CheckSharedWorkbook(string configuredPath)
        {
            PropertyPaneProfile testProfile = PropertyPaneDefaults.Create();
            return workbookService.Apply(configuredPath, testProfile);
        }

        private void ApplySharedWorkbook(PropertyPaneProfile profile)
        {
            SharedWorkbookLoaded = false;
            SharedWorkbookStatus = "Lists: local profile";

            if (profile == null || !profile.UseSharedWorkbook)
                return;

            try
            {
                PropertyPaneWorkbookLoadResult result = workbookService.Apply(profile.SharedWorkbookPath, profile);
                SharedWorkbookLoaded = true;
                SharedWorkbookStatus = "Lists: shared Excel (" + result.ListCount + " lists)";
                PropertyPaneLogger.Write("Shared workbook loaded: " + result.ResolvedPath + ". " +
                    result.ListCount + " lists, " + result.MappingCount + " drawing mappings.");
            }
            catch (Exception ex)
            {
                SharedWorkbookStatus = "Shared Excel unavailable; local fallback";
                PropertyPaneLogger.Write("Shared workbook load failed; local profile retained. " + ex.Message);
            }
        }

        public void Save(PropertyPaneProfile profile)
        {
            Normalize(profile);
            Validate(profile);
            Directory.CreateDirectory(SettingsFolder);

            string temporaryPath = ProfilePath + ".tmp";
            using (FileStream stream = File.Create(temporaryPath))
            {
                serializer.Serialize(stream, profile);
            }

            if (File.Exists(ProfilePath))
                File.Replace(temporaryPath, ProfilePath, ProfilePath + ".last-known-good", true);
            else
                File.Move(temporaryPath, ProfilePath);
        }

        public PropertyPaneProfile Clone(PropertyPaneProfile source)
        {
            if (source == null)
                return PropertyPaneDefaults.Create();

            using (MemoryStream stream = new MemoryStream())
            {
                serializer.Serialize(stream, source);
                stream.Position = 0;
                PropertyPaneProfile clone = serializer.Deserialize(stream) as PropertyPaneProfile;
                Normalize(clone);
                Validate(clone);
                return clone;
            }
        }

        public PropertyPaneProfile Import(string sourcePath)
        {
            if (string.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath))
                throw new FileNotFoundException("The selected profile does not exist.", sourcePath);

            PropertyPaneProfile profile;
            using (FileStream stream = File.OpenRead(sourcePath))
            {
                profile = serializer.Deserialize(stream) as PropertyPaneProfile;
            }

            Normalize(profile);
            Validate(profile);
            Backup("before-import");
            Save(profile);
            return profile;
        }

        public void Export(PropertyPaneProfile profile, string destinationPath)
        {
            Validate(profile);
            using (FileStream stream = File.Create(destinationPath))
            {
                serializer.Serialize(stream, profile);
            }
        }

        public PropertyPaneProfile Reset()
        {
            Backup("before-reset");
            PropertyPaneProfile profile = PropertyPaneDefaults.Create();
            Save(profile);
            return profile;
        }

        private string Backup(string reason)
        {
            if (!File.Exists(ProfilePath))
                return string.Empty;

            string folder = Path.Combine(SettingsFolder, "Backups");
            Directory.CreateDirectory(folder);
            string path = Path.Combine(folder,
                Path.GetFileNameWithoutExtension(FileName) + "_" + reason + "_" +
                DateTime.Now.ToString("yyyyMMdd_HHmmssfff") + ".xml");
            File.Copy(ProfilePath, path, false);
            return path;
        }

        private static bool Migrate(PropertyPaneProfile profile)
        {
            if (profile == null)
                throw new InvalidDataException("The profile is empty.");
            if (profile.SchemaVersion > PropertyPaneDefaults.CurrentSchemaVersion)
                throw new InvalidDataException("The property-pane profile was created by a newer Cabin Tools version (schema " +
                    profile.SchemaVersion + ").");
            if (profile.SchemaVersion < 1)
                throw new InvalidDataException("Unsupported property-pane profile schema " + profile.SchemaVersion + ".");

            bool migrated = false;
            if (profile.SchemaVersion == 1)
            {
                foreach (PropertyPaneField field in (profile.Layouts ?? new List<PropertyPaneLayout>())
                    .Where(l => l != null)
                    .SelectMany(l => l.Groups ?? new List<PropertyPaneGroup>())
                    .Where(g => g != null)
                    .SelectMany(g => g.Fields ?? new List<PropertyPaneField>()))
                {
                    field.BlankMeansNoChange = true;
                    field.AllowExplicitClear = !field.ReadOnly &&
                        field.ControlType != PropertyPaneControlType.ReadOnly &&
                        field.ControlType != PropertyPaneControlType.ReadOnlyPreview &&
                        field.ControlType != PropertyPaneControlType.Automatic;
                }
                profile.SchemaVersion = 2;
                migrated = true;
            }

            return migrated;
        }

        internal static void Validate(PropertyPaneProfile profile)
        {
            if (profile == null)
                throw new InvalidDataException("The profile is empty.");
            if (profile.SchemaVersion != PropertyPaneDefaults.CurrentSchemaVersion)
                throw new InvalidDataException("Unsupported property-pane profile schema " + profile.SchemaVersion + ".");
            if (profile.Layouts == null || profile.Layouts.Count == 0)
                throw new InvalidDataException("The profile contains no layouts.");

            if (profile.Layouts.GroupBy(l => l.DocumentKind).Any(g => g.Count() > 1))
                throw new InvalidDataException("The profile contains more than one layout for the same document type.");

            foreach (PropertyPaneLayout layout in profile.Layouts)
            {
                if (layout == null)
                    throw new InvalidDataException("The profile contains an empty layout.");
                if (layout.Groups == null)
                    throw new InvalidDataException(layout.DocumentKind + " layout has no group collection.");
                if (layout.Groups.Any(g => g == null || string.IsNullOrWhiteSpace(g.Id) || string.IsNullOrWhiteSpace(g.Label)))
                    throw new InvalidDataException(layout.DocumentKind + " contains a group without an ID or label.");
                if (layout.Groups.GroupBy(g => g.Id, StringComparer.OrdinalIgnoreCase).Any(g => g.Count() > 1))
                    throw new InvalidDataException(layout.DocumentKind + " contains duplicate group IDs.");

                List<PropertyPaneField> fields = layout.Groups
                    .SelectMany(g => g.Fields ?? new List<PropertyPaneField>()).ToList();
                if (fields.GroupBy(f => f.Id, StringComparer.OrdinalIgnoreCase).Any(g => g.Count() > 1))
                    throw new InvalidDataException(layout.DocumentKind + " contains duplicate field IDs.");

                foreach (PropertyPaneField field in fields)
                {
                    if (string.IsNullOrWhiteSpace(field.Id) || string.IsNullOrWhiteSpace(field.PropertyName))
                        throw new InvalidDataException("Every field requires a stable ID and property name.");
                    if (string.IsNullOrWhiteSpace(field.Label))
                        throw new InvalidDataException("Field '" + field.Id + "' requires a label.");
                    if (field.AllowedScopes == null || field.AllowedScopes.Count == 0)
                        throw new InvalidDataException("Field '" + field.Label + "' requires at least one allowed scope.");
                    if (!field.AllowedScopes.Contains(field.DefaultScope))
                        throw new InvalidDataException("Field '" + field.Label + "' has a default scope that is not allowed.");
                    if (layout.DocumentKind == PropertyPaneDocumentKind.Drawing &&
                        field.AllowedScopes.Any(s => s != PropertyPaneScope.Document))
                        throw new InvalidDataException("Drawing field '" + field.Label + "' can use document scope only.");
                    if (field.MaxLength < 0)
                        throw new InvalidDataException("Field '" + field.Label + "' has an invalid maximum length.");
                    if (!string.IsNullOrWhiteSpace(field.ValidationPattern))
                    {
                        try { new Regex(field.ValidationPattern); }
                        catch (Exception ex)
                        {
                            throw new InvalidDataException("Field '" + field.Label + "' has an invalid validation pattern: " + ex.Message);
                        }
                    }
                }
            }

            if (profile.Dimensions == null || profile.Dimensions.Count == 0)
                throw new InvalidDataException("The profile contains no part-dimension mappings.");
            if (profile.Dimensions.Any(d => d == null || string.IsNullOrWhiteSpace(d.Id) ||
                string.IsNullOrWhiteSpace(d.Label) || string.IsNullOrWhiteSpace(d.FeatureName) ||
                string.IsNullOrWhiteSpace(d.FromPlane)))
                throw new InvalidDataException("Every dimension mapping requires an ID, label, controlling plane, and reference plane.");
            if (profile.Dimensions.GroupBy(d => d.Id, StringComparer.OrdinalIgnoreCase).Any(g => g.Count() > 1))
                throw new InvalidDataException("The profile contains duplicate dimension IDs.");
        }

        private static void Normalize(PropertyPaneProfile profile)
        {
            profile.Lists = profile.Lists ?? new List<PropertyPaneNamedList>();
            profile.SharedWorkbookPath = profile.SharedWorkbookPath ?? string.Empty;
            profile.DrawingNumberMappings = profile.DrawingNumberMappings ?? new List<DrawingNumberMap>();
            profile.Dimensions = profile.Dimensions ?? new List<DimensionMap>();
            profile.PropertyCatalog = profile.PropertyCatalog ?? new List<string>();

            foreach (PropertyPaneLayout layout in profile.Layouts)
            {
                layout.Groups = layout.Groups ?? new List<PropertyPaneGroup>();
                layout.Groups = layout.Groups.OrderBy(g => g.Order).ToList();
                foreach (PropertyPaneGroup group in layout.Groups)
                {
                    group.Fields = (group.Fields ?? new List<PropertyPaneField>())
                        .OrderBy(f => f.Order).ToList();
                    foreach (PropertyPaneField field in group.Fields)
                    {
                        field.Id = (field.Id ?? string.Empty).Trim();
                        field.Label = (field.Label ?? string.Empty).Trim();
                        field.PropertyName = (field.PropertyName ?? string.Empty).Trim();
                        field.ListName = field.ListName ?? string.Empty;
                        field.AutomaticValue = field.AutomaticValue ?? string.Empty;
                        field.DefaultExpression = field.DefaultExpression ?? string.Empty;
                        field.DefaultValue = field.DefaultValue ?? string.Empty;
                        field.ValidationPattern = field.ValidationPattern ?? string.Empty;
                        field.ValidationMessage = field.ValidationMessage ?? string.Empty;
                        field.VisibleWhenFieldId = field.VisibleWhenFieldId ?? string.Empty;
                        field.VisibleWhenValue = field.VisibleWhenValue ?? string.Empty;
                        field.EnabledWhenFieldId = field.EnabledWhenFieldId ?? string.Empty;
                        field.EnabledWhenValue = field.EnabledWhenValue ?? string.Empty;
                        field.HelpText = field.HelpText ?? string.Empty;
                        field.AllowedScopes = field.AllowedScopes == null || field.AllowedScopes.Count == 0
                            ? new List<PropertyPaneScope> { PropertyPaneScope.Document }
                            : field.AllowedScopes.Distinct().ToList();
                        if (!field.AllowedScopes.Contains(field.DefaultScope))
                            field.DefaultScope = field.AllowedScopes[0];
                    }
                }
            }
        }
    }
}
